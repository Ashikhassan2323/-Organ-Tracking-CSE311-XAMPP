<?php
require_once 'includes/config.php';

$adminPass = password_hash('admin', PASSWORD_BCRYPT);
$hospitalPass = password_hash('hospital', PASSWORD_BCRYPT);

$conn->query("UPDATE admin SET password_hash='$adminPass' WHERE username='admin'");
$conn->query("UPDATE hospital SET password_hash='$hospitalPass'");

echo "Passwords reset successfully.<br>";
echo "Admin username: admin<br>";
echo "Admin password: admin<br>";
echo "Hospital password for all hospitals: hospital<br>";
?>