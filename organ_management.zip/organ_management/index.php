<?php
session_start();

if (isset($_SESSION['role'])) {
    $r = $_SESSION['role'];

    if ($r === 'admin') {
        header("Location: admin/dashboard.php");
    } elseif ($r === 'hospital') {
        header("Location: hospital/dashboard.php");
    } elseif ($r === 'donor') {
        header("Location: donor/dashboard.php");
    } else {
        header("Location: viewer/index.php");
    }
    exit;
}

require_once 'includes/config.php';

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $role = sanitize($conn, $_POST['role'] ?? '');

    if ($role === 'admin') {
        $username = sanitize($conn, $_POST['username'] ?? '');
        $password = sanitize($conn, $_POST['admin_password'] ?? '');

        $sql = "SELECT * FROM admin WHERE username='$username' AND password_hash='$password' LIMIT 1";
        $res = $conn->query($sql);

        if ($res && $res->num_rows > 0) {
            $user = $res->fetch_assoc();
            $_SESSION['role'] = 'admin';
            $_SESSION['admin_id'] = $user['admin_id'];
            $_SESSION['name'] = $user['full_name'] ?? 'Admin';
            header("Location: admin/dashboard.php");
            exit;
        } else {
            $error = "Invalid admin credentials.";
        }

    } elseif ($role === 'hospital') {
        $login = sanitize($conn, $_POST['hospital_login'] ?? '');
        $password = sanitize($conn, $_POST['hospital_password'] ?? '');

        $sql = "SELECT * FROM hospital 
                WHERE (registration_no='$login' OR hospital_name='$login')
                AND password_hash='$password'
                AND subscription_status='active'
                LIMIT 1";
        $res = $conn->query($sql);

        if ($res && $res->num_rows > 0) {
            $user = $res->fetch_assoc();
            $_SESSION['role'] = 'hospital';
            $_SESSION['hospital_id'] = $user['hospital_id'];
            $_SESSION['name'] = $user['hospital_name'] ?? 'Hospital';
            header("Location: hospital/dashboard.php");
            exit;
        } else {
            $error = "Invalid hospital credentials.";
        }

    } elseif ($role === 'donor') {
        $login = sanitize($conn, $_POST['donor_login'] ?? '');
        $password = $_POST['donor_password'] ?? '';
        $donorId = (int)$login;

        $sql = "SELECT * FROM donor WHERE phone='$login' OR donor_id=$donorId LIMIT 1";
        $res = $conn->query($sql);

        if ($res && $res->num_rows > 0) {
            $user = $res->fetch_assoc();

            $storedPassword = '';
            if (isset($user['password_hash'])) {
                $storedPassword = $user['password_hash'];
            } elseif (isset($user['password'])) {
                $storedPassword = $user['password'];
            }

            $ok = false;

            if ($password === $storedPassword) {
                $ok = true;
            } elseif (function_exists('password_verify') && password_verify($password, $storedPassword)) {
                $ok = true;
            }

            if ($ok) {
                $_SESSION['role'] = 'donor';
                $_SESSION['donor_id'] = $user['donor_id'];
                $_SESSION['name'] = $user['full_name'] ?? 'Donor';
                header("Location: donor/dashboard.php");
                exit;
            } else {
                $error = "Invalid donor credentials.";
            }
        } else {
            $error = "Invalid donor credentials.";
        }

    } elseif ($role === 'viewer') {
        header("Location: viewer/index.php");
        exit;

    } else {
        $error = "Please select a role.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Organ Management System — Login</title>
<link rel="stylesheet" href="css/style.css">
<style>
.form-section {
    display: none;
}
.form-section.active {
    display: block;
}
</style>
</head>
<body>
<div class="login-page">
<div class="login-box">
    <div class="login-logo">
        <div class="emoji">🫀</div>
        <h1>OrganMS</h1>
        <p>Hospital Organ Management System</p>
    </div>

    <?php if ($error): ?>
    <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <form method="POST" id="loginForm">
        <p style="font-size:13px;color:#64748b;margin-bottom:12px;text-align:center;">Who do you want to login as?</p>

        <div class="role-selector">
            <div class="role-btn" onclick="selectRole('admin')" id="btn-admin">
                <span class="role-icon">🔐</span>Admin
            </div>
            <div class="role-btn" onclick="selectRole('hospital')" id="btn-hospital">
                <span class="role-icon">🏥</span>Hospital
            </div>
            <div class="role-btn" onclick="selectRole('donor')" id="btn-donor">
                <span class="role-icon">💉</span>Donor
            </div>
            <div class="role-btn role-btn-viewer" onclick="selectRole('viewer')" id="btn-viewer">
                <span class="role-icon">👁️</span>Viewer (Public Access — No Login Required)
            </div>
        </div>

        <input type="hidden" name="role" id="roleInput" value="">

        <div class="form-section" id="section-admin">
            <div class="form-group">
                <label>Username</label>
                <input type="text" name="username" class="form-control" placeholder="Enter admin username">
            </div>
            <div class="form-group">
                <label>Password</label>
                <input type="password" name="admin_password" class="form-control" placeholder="Enter password">
            </div>
        </div>

        <div class="form-section" id="section-hospital">
            <div class="form-group">
                <label>Registration No or Hospital Name</label>
                <input type="text" name="hospital_login" class="form-control" placeholder="REG-001 or Hospital Name">
            </div>
            <div class="form-group">
                <label>Password</label>
                <input type="password" name="hospital_password" class="form-control" placeholder="Enter password">
            </div>
            <p style="font-size:12px;color:#64748b;">New hospital? <a href="hospital/register.php" style="color:#2563eb;">Register here</a></p>
        </div>

        <div class="form-section" id="section-donor">
            <div class="form-group">
                <label>Phone Number or Donor ID</label>
                <input type="text" name="donor_login" class="form-control" placeholder="017XXXXXXXX or Donor ID">
            </div>
            <div class="form-group">
                <label>Password</label>
                <input type="password" name="donor_password" class="form-control" placeholder="Enter password">
            </div>
            <p style="font-size:12px;color:#64748b;">New donor? <a href="donor/register.php" style="color:#2563eb;">Register free</a></p>
        </div>

        <div id="submitSection" style="display:none;margin-top:4px;">
            <button type="submit" class="btn btn-primary" style="width:100%;justify-content:center;">Login →</button>
        </div>
    </form>
</div>
</div>

<script>
function selectRole(role) {
    document.querySelectorAll('.role-btn').forEach(function(b) {
        b.classList.remove('selected');
    });

    document.querySelectorAll('.form-section').forEach(function(s) {
        s.classList.remove('active');
    });

    document.getElementById('btn-' + role).classList.add('selected');
    document.getElementById('roleInput').value = role;

    var submitButton = document.getElementById('submitSection').querySelector('button');

    if (role !== 'viewer') {
        var section = document.getElementById('section-' + role);
        if (section) {
            section.classList.add('active');
        }
        submitButton.textContent = 'Login →';
        document.getElementById('submitSection').style.display = 'block';
    } else {
        submitButton.textContent = 'View Public Data →';
        document.getElementById('submitSection').style.display = 'block';
    }
}
<?php if ($error && isset($_POST['role'])): ?>
selectRole('<?= htmlspecialchars($_POST['role']) ?>');
<?php endif; ?>
</script>
</body>
</html>