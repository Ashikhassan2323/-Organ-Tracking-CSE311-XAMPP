<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="refresh" content="20">
<title>Public Stock Viewer — OrganMS</title>
<link rel="stylesheet" href="../css/style.css">
<style>
body { background: #f1f5f9; }
.viewer-header {
    background: linear-gradient(135deg, #0f172a 0%, #1e3a5f 100%);
    color: #fff;
    padding: 24px 32px;
    display: flex;
    align-items: center;
    justify-content: space-between;
}
.viewer-header h1 { font-size: 22px; }
.viewer-header p { font-size: 13px; color: #94a3b8; margin-top: 4px; }
.viewer-body { max-width: 1100px; margin: 0 auto; padding: 28px 20px; }
.hospital-card {
    background: #fff;
    border-radius: 14px;
    border: 1px solid #e2e8f0;
    margin-bottom: 24px;
    overflow: hidden;
}
.hospital-header {
    background: linear-gradient(90deg, #1e3a5f, #2563eb);
    color: #fff;
    padding: 16px 24px;
    display: flex;
    align-items: center;
    justify-content: space-between;
}
.hospital-header h3 { font-size: 16px; }
.hospital-header small { font-size: 12px; opacity: 0.8; }
.hospital-body { padding: 0; }
.organ-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(180px, 1fr));
    gap: 12px;
    padding: 16px 20px;
}
.organ-chip {
    background: #f0fdf4;
    border: 1px solid #bbf7d0;
    border-radius: 10px;
    padding: 14px;
    text-align: center;
}
.organ-chip .organ-name { font-weight: 700; font-size: 14px; color: #166534; }
.organ-chip .blood { font-size: 12px; color: #64748b; margin-top: 4px; }
.organ-chip .status-dot { width: 8px; height: 8px; background: #22c55e; border-radius: 50%; display: inline-block; animation: pulse 1.5s infinite; margin-right: 4px; }
@keyframes pulse { 0%,100%{opacity:1;transform:scale(1)} 50%{opacity:.5;transform:scale(1.3)} }
.no-organs { padding: 20px; color: #94a3b8; font-size: 13px; text-align: center; }
.summary-bar {
    display: flex;
    gap: 20px;
    background: #fff;
    border-radius: 12px;
    border: 1px solid #e2e8f0;
    padding: 16px 24px;
    margin-bottom: 24px;
    flex-wrap: wrap;
}
.summary-item { text-align: center; }
.summary-item .val { font-size: 24px; font-weight: 700; color: #2563eb; }
.summary-item .lbl { font-size: 11px; color: #94a3b8; text-transform: uppercase; letter-spacing: .5px; }
</style>
</head>
<body>

<?php
require_once '../includes/config.php';
$hospitals = $conn->query("SELECT h.*,
    (SELECT COUNT(*) FROM organ WHERE hospital_id=h.hospital_id AND availability_status='available') as available_count
    FROM hospital h WHERE h.subscription_status='active' ORDER BY h.hospital_name");

$totals = $conn->query("SELECT
    (SELECT COUNT(*) FROM hospital WHERE subscription_status='active') as hospitals,
    (SELECT COUNT(*) FROM organ WHERE availability_status='available') as organs,
    (SELECT COUNT(*) FROM donor WHERE eligibility_status='eligible') as donors,
    (SELECT COUNT(*) FROM recipient WHERE status='waiting') as waiting
")->fetch_assoc();
?>

<div class="viewer-header">
    <div>
        <h1>🫀 OrganMS — Public Stock Viewer</h1>
        <p>Live organ availability across registered hospitals · Auto-refreshes every 20 seconds</p>
    </div>
    <div style="display:flex;gap:12px;align-items:center">
        <span style="font-size:12px;color:#94a3b8"><span style="display:inline-block;width:8px;height:8px;background:#22c55e;border-radius:50%;animation:pulse 1.5s infinite;margin-right:5px"></span>Live</span>
        <a href="../index.php" style="color:#60a5fa;font-size:13px;border:1px solid #334155;padding:7px 14px;border-radius:8px">🔐 Staff Login</a>
        <a href="../donor/register.php" style="background:#2563eb;color:#fff;font-size:13px;padding:7px 14px;border-radius:8px">💉 Register as Donor</a>
        <a href="../hospital/register.php" style="background:#16a34a;color:#fff;font-size:13px;padding:7px 14px;border-radius:8px">🏥 Register Hospital</a>
    </div>
</div>

<div class="viewer-body">

<div class="summary-bar">
    <div class="summary-item"><div class="val"><?=$totals['hospitals']?></div><div class="lbl">Active Hospitals</div></div>
    <div class="summary-item"><div class="val" style="color:#16a34a"><?=$totals['organs']?></div><div class="lbl">Organs Available</div></div>
    <div class="summary-item"><div class="val"><?=$totals['donors']?></div><div class="lbl">Eligible Donors</div></div>
    <div class="summary-item"><div class="val" style="color:#d97706"><?=$totals['waiting']?></div><div class="lbl">Recipients Waiting</div></div>
</div>

<?php while($h=$hospitals->fetch_assoc()):
    $organs=$conn->query("SELECT o.*,d.blood_group FROM organ o JOIN donor d ON o.donor_id=d.donor_id WHERE o.hospital_id={$h['hospital_id']} AND o.availability_status='available'");
?>
<div class="hospital-card">
    <div class="hospital-header">
        <div>
            <h3>🏥 <?=htmlspecialchars($h['hospital_name'])?></h3>
            <small><?=htmlspecialchars($h['city'])?> · <?=htmlspecialchars($h['address'])?> · <?=htmlspecialchars($h['phone'])?></small>
        </div>
        <div style="text-align:right">
            <div style="font-size:22px;font-weight:700"><?=$h['available_count']?></div>
            <div style="font-size:11px;opacity:.8">organs available</div>
        </div>
    </div>
    <div class="hospital-body">
    <?php if($organs->num_rows===0): ?>
        <div class="no-organs">No organs currently available at this hospital.</div>
    <?php else: ?>
    <div class="organ-grid">
    <?php while($o=$organs->fetch_assoc()): ?>
        <div class="organ-chip">
            <div style="margin-bottom:6px"><span class="status-dot"></span><small style="font-size:11px;color:#16a34a">Available</small></div>
            <div class="organ-name"><?=htmlspecialchars($o['organ_type'])?></div>
            <div class="blood">Blood: <b><?=$o['blood_group']?></b></div>
        </div>
    <?php endwhile; ?>
    </div>
    <?php endif; ?>
    </div>
</div>
<?php endwhile; ?>

<div style="text-align:center;color:#94a3b8;font-size:12px;padding:20px 0">
    OrganMS — Hospital Organ Management System · CSE311 Project<br>
    Last updated: <?=date('M d, Y H:i:s')?>
</div>
</div>
</body>
</html>
