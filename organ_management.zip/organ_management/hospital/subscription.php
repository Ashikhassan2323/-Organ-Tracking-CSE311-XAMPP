<?php
session_start();
require_once '../includes/auth.php';
require_once '../includes/config.php';
require_once '../includes/sidebar.php';
requireHospital();
$hid = $_SESSION['hospital_id'];
$msg='';$err='';

$hospital = $conn->query("SELECT * FROM hospital WHERE hospital_id=$hid")->fetch_assoc();

if ($_SERVER['REQUEST_METHOD']==='POST') {
    $txn = sanitize($conn, $_POST['bkash_transaction_id']);
    if (!$txn) { $err="Please enter your bKash transaction ID."; }
    else {
        $conn->query("INSERT INTO payments (payer_type,hospital_id,amount,bkash_transaction_id,payment_status,purpose)
            VALUES ('hospital',$hid,5000,'$txn','pending','Annual Subscription')");
        $conn->query("UPDATE hospital SET bkash_transaction_id='$txn' WHERE hospital_id=$hid");
        $msg = "Payment submitted! Admin will verify and activate your subscription shortly.";
    }
}

$payments = $conn->query("SELECT * FROM payments WHERE hospital_id=$hid AND payer_type='hospital' ORDER BY payment_date DESC");
?>
<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8"><title>Subscription — Hospital</title><link rel="stylesheet" href="../css/style.css"></head>
<body><div class="wrapper"><?php renderSidebar('hospital','subscription.php');?>
<div class="main-content">
<div class="topbar"><h1>💳 Subscription & Billing</h1></div>
<div class="page-body">
<?php if($msg):?><div class="alert alert-success"><?=$msg?></div><?php endif;?>
<?php if($err):?><div class="alert alert-danger"><?=$err?></div><?php endif;?>

<div style="display:grid;grid-template-columns:1fr 1fr;gap:20px">
<div class="card">
<div class="card-title">📋 Subscription Status</div>
<div style="text-align:center;padding:20px 0">
<?php if($hospital['subscription_status']==='active'): ?>
<div style="font-size:52px">✅</div>
<h2 style="color:#16a34a;margin:10px 0">Active</h2>
<p style="color:#64748b">Your subscription is active. Full access granted.</p>
<?php if($hospital['subscription_paid_at']): ?>
<p style="margin-top:8px;font-size:13px;color:#94a3b8">Activated: <?=date('M d, Y',strtotime($hospital['subscription_paid_at']))?></p>
<?php endif; ?>
<?php elseif($hospital['subscription_status']==='pending'): ?>
<div style="font-size:52px">⏳</div>
<h2 style="color:#d97706;margin:10px 0">Pending</h2>
<p style="color:#64748b">Payment submitted. Awaiting admin verification.</p>
<?php else: ?>
<div style="font-size:52px">❌</div>
<h2 style="color:#dc2626;margin:10px 0">Expired / Inactive</h2>
<p style="color:#64748b">Please renew your subscription to continue.</p>
<?php endif; ?>
</div>
</div>

<div class="card">
<div class="card-title">💰 Pay via bKash</div>
<div class="alert alert-info" style="font-size:13px">
    <b>Annual Fee:</b> ৳5,000<br>
    <b>bKash Number:</b> 01700000000<br>
    <b>Reference:</b> <?=htmlspecialchars($hospital['registration_no'])?>
</div>
<form method="POST">
<div class="form-group"><label>bKash Transaction ID</label>
<input name="bkash_transaction_id" class="form-control" required placeholder="e.g. BKS20240001">
</div>
<button type="submit" class="btn btn-success" style="width:100%">Submit Payment</button>
</form>
</div>
</div>

<div class="card">
<div class="card-title">📋 Payment History</div>
<div class="table-wrap"><table>
<thead><tr><th>Amount</th><th>bKash TXN</th><th>Purpose</th><th>Date</th><th>Status</th></tr></thead>
<tbody>
<?php while($p=$payments->fetch_assoc()):?>
<tr>
<td><b>৳<?=number_format($p['amount'],2)?></b></td>
<td><code><?=htmlspecialchars($p['bkash_transaction_id'])?></code></td>
<td><?=htmlspecialchars($p['purpose'])?></td>
<td><?=date('M d, Y',strtotime($p['payment_date']))?></td>
<td><?php $sc=['pending'=>'badge-warning','verified'=>'badge-success','rejected'=>'badge-danger'];?>
<span class="badge <?=$sc[$p['payment_status']]?>"><?=ucfirst($p['payment_status'])?></span></td>
</tr>
<?php endwhile;?>
</tbody></table></div></div>
</div></div></div>
</body></html>
