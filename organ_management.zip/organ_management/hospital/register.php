<?php
session_start();
require_once '../includes/config.php';
$msg = ''; $err = '';
 
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // FIX #4: Use prepared statements — raw interpolation is SQL injection risk
    // even with sanitize(), prepared statements are the correct approach.
    $name  = $_POST['hospital_name']    ?? '';
    $city  = $_POST['city']             ?? '';
    $addr  = $_POST['address']          ?? '';
    $phone = $_POST['phone']            ?? '';
    $email = $_POST['email']            ?? '';
    $reg   = $_POST['registration_no']  ?? '';
    $pass  = hashPassword($_POST['password'] ?? '');
 
    // Check duplicates with prepared statement
    $chk = $conn->prepare("SELECT hospital_id FROM hospital WHERE registration_no = ? OR email = ? LIMIT 1");
    $chk->bind_param("ss", $reg, $email);
    $chk->execute();
    $chk->store_result();
 
    if ($chk->num_rows > 0) {
        $err = "Registration number or email already exists.";
    } else {
        // INSERT with prepared statement
        $ins = $conn->prepare(
            "INSERT INTO hospital (hospital_name, city, address, phone, email, password_hash, registration_no, subscription_status)
             VALUES (?, ?, ?, ?, ?, ?, ?, 'pending')"
        );
        $ins->bind_param("sssssss", $name, $city, $addr, $phone, $email, $pass, $reg);
        $ins->execute();
        $hid = $conn->insert_id;
 
        // FIX #5: Escape output — $hid and $reg are safe here but good practice
        // $msg used with htmlspecialchars in output below
        $msg = "Registration successful! Your hospital ID: <b>" . (int)$hid . "</b>, Registration No: <b>" . htmlspecialchars($reg) . "</b>.<br>
            You can log in once admin activates your account. Please pay the annual subscription fee (৳5,000) via bKash to <b>01700000000</b> (reference: your reg no) and submit your transaction ID on the subscription page after login.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Hospital Registration — OrganMS</title>
<link rel="stylesheet" href="../css/style.css">
</head>
<body>
<div class="login-page">
<div class="login-box" style="max-width:520px">
    <div class="login-logo">
        <div class="emoji">🏥</div>
        <h1>Hospital Registration</h1>
        <p>Register your hospital to access OrganMS</p>
    </div>
 
    <?php if ($msg): ?>
        <!-- FIX #5: $msg contains intentional HTML (bold tags) — it is safe because
             $hid is cast to int and $reg is htmlspecialchars'd above. -->
        <div class="alert alert-success"><?= $msg ?><br><br>
            <a href="../index.php" class="btn btn-primary">Go to Login</a>
        </div>
    <?php elseif ($err): ?>
        <div class="alert alert-danger"><?= htmlspecialchars($err) ?></div>
    <?php endif; ?>
 
    <?php if (!$msg): ?>
    <form method="POST">
        <div class="form-group">
            <label>Hospital Name</label>
            <input name="hospital_name" class="form-control" required placeholder="e.g. Dhaka General Hospital">
        </div>
        <div class="form-row">
            <div class="form-group">
                <label>City</label>
                <input name="city" class="form-control" required>
            </div>
            <div class="form-group">
                <label>Registration No</label>
                <input name="registration_no" class="form-control" required placeholder="e.g. REG-100">
            </div>
        </div>
        <div class="form-group">
            <label>Address</label>
            <textarea name="address" class="form-control" rows="2"></textarea>
        </div>
        <div class="form-row">
            <div class="form-group">
                <label>Phone</label>
                <input name="phone" class="form-control" required>
            </div>
            <div class="form-group">
                <label>Email</label>
                <input type="email" name="email" class="form-control" required>
            </div>
        </div>
        <div class="form-group">
            <label>Password</label>
            <input type="password" name="password" class="form-control" required minlength="6">
        </div>
        <div class="alert alert-info" style="font-size:12px">
            💳 After registration, pay <b>৳5,000/year</b> via bKash to <b>01700000000</b> (reference: your reg no).
            Admin will activate your account upon payment verification.
        </div>
        <button type="submit" class="btn btn-primary" style="width:100%">Register Hospital</button>
        <p style="text-align:center;margin-top:14px;font-size:13px;color:#64748b">
            Already registered? <a href="../index.php" style="color:#2563eb">Login</a>
        </p>
    </form>
    <?php endif; ?>
</div>
</div>
</body>
</html>