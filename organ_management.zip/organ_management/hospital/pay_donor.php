<?php
session_start();
require_once '../includes/auth.php';
require_once '../includes/config.php';
require_once '../includes/sidebar.php';
requireHospital();
$hid = $_SESSION['hospital_id'];
$msg='';$err='';

$did = isset($_GET['donor_id']) ? (int)$_GET['donor_id'] : 0;
$donor = null;
if ($did) {
    $res = $conn->query("SELECT * FROM donor WHERE donor_id=$did LIMIT 1");
    $donor = $res->fetch_assoc();
}

if ($_SERVER['REQUEST_METHOD']==='POST') {
    $donor_id = (int)$_POST['donor_id'];
    $amount = (float)$_POST['amount'];
    $txn = sanitize($conn, $_POST['bkash_transaction_id']);
    $purpose = sanitize($conn, $_POST['purpose']);

    if (!$donor_id || !$amount || !$txn) {
        $err = "Please fill all required fields.";
    } else {
        $conn->query("INSERT INTO payments (payer_type,hospital_id,donor_id,amount,bkash_transaction_id,payment_status,purpose)
            VALUES ('hospital_to_donor',$hid,$donor_id,$amount,'$txn','pending','$purpose')");
        $msg = "Payment of ৳$amount submitted for admin verification. It will show as received to the donor after verification.";
    }
}

$donors = $conn->query("SELECT * FROM donor WHERE eligibility_status='eligible' ORDER BY full_name");
$my_payments = $conn->query("SELECT p.*, d.full_name as donor_name FROM payments p JOIN donor d ON p.donor_id=d.donor_id WHERE p.hospital_id=$hid AND p.payer_type='hospital_to_donor' ORDER BY p.payment_date DESC");
?>
<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8"><title>Pay Donor — Hospital</title><link rel="stylesheet" href="../css/style.css"></head>
<body><div class="wrapper"><?php renderSidebar('hospital','pay_donor.php');?>
<div class="main-content">
<div class="topbar"><h1>💸 Pay a Donor</h1></div>
<div class="page-body">
<?php if($msg):?><div class="alert alert-success"><?=$msg?></div><?php endif;?>
<?php if($err):?><div class="alert alert-danger"><?=$err?></div><?php endif;?>

<div class="card" style="max-width:560px">
<div class="card-title">💳 Submit Payment via bKash</div>
<div class="alert alert-info" style="font-size:13px">
Send the amount to the donor directly, then submit the bKash transaction ID here. Admin will verify it before the donor sees it as paid.
</div>
<form method="POST">
<div class="form-group"><label>Select Donor</label>
<select name="donor_id" class="form-control" required>
<option value="">-- Select Eligible Donor --</option>
<?php while($d=$donors->fetch_assoc()): ?>
<option value="<?=$d['donor_id']?>" <?=($donor && $donor['donor_id']==$d['donor_id'])?'selected':''?>><?=htmlspecialchars($d['full_name'])?> (<?=$d['blood_group']?> · <?=$d['phone']?>)</option>
<?php endwhile; ?>
</select></div>
<div class="form-row">
<div class="form-group"><label>Amount (BDT)</label><input type="number" step="0.01" min="1" name="amount" class="form-control" required placeholder="5000"></div>
<div class="form-group"><label>bKash Transaction ID</label><input name="bkash_transaction_id" class="form-control" required placeholder="BKS-DONOR-001"></div>
</div>
<div class="form-group"><label>Purpose</label><input name="purpose" class="form-control" value="Donor support payment" placeholder="Purpose of payment"></div>
<button type="submit" class="btn btn-success">Submit Payment</button>
</form>
</div>

<div class="card">
<div class="card-title">📋 My Donor Payments</div>
<div class="table-wrap"><table>
<thead><tr><th>Donor</th><th>Amount</th><th>bKash TXN</th><th>Purpose</th><th>Date</th><th>Status</th></tr></thead>
<tbody>
<?php if($my_payments->num_rows===0): ?>
<tr><td colspan="6" style="text-align:center;color:#64748b;padding:30px">No donor payments submitted yet.</td></tr>
<?php else: while($p=$my_payments->fetch_assoc()): ?>
<tr>
<td><?=htmlspecialchars($p['donor_name'])?></td>
<td><b>৳<?=number_format($p['amount'],2)?></b></td>
<td><code><?=htmlspecialchars($p['bkash_transaction_id'])?></code></td>
<td><?=htmlspecialchars($p['purpose'])?></td>
<td><?=date('M d, Y',strtotime($p['payment_date']))?></td>
<td><?php $sc=['pending'=>'badge-warning','verified'=>'badge-success','rejected'=>'badge-danger'];?><span class="badge <?=$sc[$p['payment_status']]?>"><?=ucfirst($p['payment_status'])?></span></td>
</tr>
<?php endwhile; endif; ?>
</tbody></table></div></div>
</div></div></div>
</body></html>
