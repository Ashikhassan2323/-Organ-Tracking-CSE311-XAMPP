<?php
session_start();
require_once '../includes/auth.php';
require_once '../includes/config.php';
require_once '../includes/sidebar.php';
requireHospital();

$hid = $_SESSION['hospital_id'];
$msg = '';
$err = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'add_match') {
        $rid = (int)$_POST['recipient_id'];
        $oid = (int)$_POST['organ_id'];

        $checkRecipient = $conn->query("
            SELECT *
            FROM recipient
            WHERE recipient_id=$rid
              AND hospital_id=$hid
              AND status='waiting'
            LIMIT 1
        ");

        $checkOrgan = $conn->query("
            SELECT *
            FROM organ
            WHERE organ_id=$oid
              AND hospital_id=$hid
              AND approval_status='accepted'
              AND availability_status='available'
            LIMIT 1
        ");

        if ($checkRecipient->num_rows === 0) {
            $err = "Recipient is not available for matching.";
        } elseif ($checkOrgan->num_rows === 0) {
            $err = "Organ is not accepted/available for this hospital.";
        } else {
            $duplicate = $conn->query("
                SELECT match_id
                FROM match_record
                WHERE recipient_id=$rid
                  AND organ_id=$oid
                  AND match_status IN ('pending','confirmed')
                LIMIT 1
            ");

            if ($duplicate->num_rows > 0) {
                $err = "This match already exists.";
            } else {
                if ($conn->query("INSERT INTO match_record (recipient_id, organ_id) VALUES ($rid, $oid)")) {
                    $conn->query("UPDATE organ SET availability_status='matched' WHERE organ_id=$oid");
                    $conn->query("UPDATE recipient SET status='matched' WHERE recipient_id=$rid");
                    $msg = "Match created successfully.";
                } else {
                    $err = "Failed to create match: " . $conn->error;
                }
            }
        }

    } elseif ($action === 'confirm') {
        $mid = (int)$_POST['match_id'];

        $checkMatch = $conn->query("
            SELECT m.*
            FROM match_record m
            JOIN recipient r ON m.recipient_id = r.recipient_id
            JOIN organ o ON m.organ_id = o.organ_id
            WHERE m.match_id=$mid
              AND r.hospital_id=$hid
              AND o.hospital_id=$hid
              AND m.match_status='pending'
            LIMIT 1
        ");

        if ($checkMatch->num_rows === 0) {
            $err = "Match not found for this hospital.";
        } else {
            if ($conn->query("UPDATE match_record SET match_status='confirmed' WHERE match_id=$mid")) {
                $msg = "Match confirmed.";
            } else {
                $err = "Failed to confirm match: " . $conn->error;
            }
        }

    } elseif ($action === 'reject_match') {
        $mid = (int)$_POST['match_id'];

        $matchRes = $conn->query("
            SELECT m.*
            FROM match_record m
            JOIN recipient r ON m.recipient_id = r.recipient_id
            JOIN organ o ON m.organ_id = o.organ_id
            WHERE m.match_id=$mid
              AND r.hospital_id=$hid
              AND o.hospital_id=$hid
              AND m.match_status='pending'
            LIMIT 1
        ");

        $match = $matchRes->fetch_assoc();

        if ($match) {
            $ok1 = $conn->query("UPDATE match_record SET match_status='rejected' WHERE match_id=$mid");
            $ok2 = $conn->query("UPDATE organ SET availability_status='available' WHERE organ_id={$match['organ_id']}");
            $ok3 = $conn->query("UPDATE recipient SET status='waiting' WHERE recipient_id={$match['recipient_id']}");

            if ($ok1 && $ok2 && $ok3) {
                $msg = "Match rejected and records rolled back.";
            } else {
                $err = "Failed to reject match properly.";
            }
        } else {
            $err = "Match not found for this hospital.";
        }

    } elseif ($action === 'add_transplant') {
        $mid = (int)$_POST['match_id'];
        $date = sanitize($conn, $_POST['transplant_date']);
        $status = sanitize($conn, $_POST['status']);
        $notes = sanitize($conn, $_POST['notes']);

        $matchRes = $conn->query("
            SELECT
                m.*,
                o.donor_id,
                o.hospital_id AS organ_hospital_id,
                r.hospital_id AS recipient_hospital_id
            FROM match_record m
            JOIN organ o ON m.organ_id = o.organ_id
            JOIN recipient r ON m.recipient_id = r.recipient_id
            WHERE m.match_id=$mid
              AND m.match_status='confirmed'
              AND o.hospital_id=$hid
              AND r.hospital_id=$hid
            LIMIT 1
        ");

        $match = $matchRes->fetch_assoc();

        if (!$match) {
            $err = "Only confirmed matches from your hospital can be recorded as transplant.";
        } else {
            $already = $conn->query("
                SELECT transplant_id
                FROM transplant
                WHERE organ_id={$match['organ_id']}
                   OR recipient_id={$match['recipient_id']}
                LIMIT 1
            ");

            if ($already->num_rows > 0) {
                $err = "This transplant has already been recorded.";
            } else {
                $did = (int)$match['donor_id'];
                $rid = (int)$match['recipient_id'];
                $oid = (int)$match['organ_id'];

                $insert = $conn->query("
                    INSERT INTO transplant
                    (donor_id, recipient_id, organ_id, hospital_id, transplant_date, status, notes)
                    VALUES
                    ($did, $rid, $oid, $hid, '$date', '$status', '$notes')
                ");

                if ($insert) {
                    $conn->query("UPDATE organ SET availability_status='used' WHERE organ_id=$oid");
                    $conn->query("UPDATE recipient SET status='transplanted' WHERE recipient_id=$rid");
                    $msg = "Transplant recorded successfully.";
                } else {
                    $err = "Failed to record transplant: " . $conn->error;
                }
            }
        }
    }
}

$matches = $conn->query("
    SELECT
        m.*,
        r.full_name AS rec_name,
        r.blood_group AS rec_blood,
        r.needed_organ_type,
        r.urgency_level,
        o.organ_type,
        o.organ_id,
        d.full_name AS donor_name,
        d.blood_group AS donor_blood
    FROM match_record m
    JOIN recipient r ON m.recipient_id = r.recipient_id
    JOIN organ o ON m.organ_id = o.organ_id
    JOIN donor d ON o.donor_id = d.donor_id
    WHERE r.hospital_id=$hid
      AND o.hospital_id=$hid
    ORDER BY m.matched_on DESC, m.match_id DESC
");

$recipients = $conn->query("
    SELECT recipient_id, full_name, blood_group, needed_organ_type, urgency_level
    FROM recipient
    WHERE hospital_id=$hid
      AND status='waiting'
    ORDER BY FIELD(urgency_level,'Critical','High','Medium','Low'), registration_date ASC
");
$r_arr = [];
while ($r = $recipients->fetch_assoc()) $r_arr[] = $r;

$avail_organs = $conn->query("
    SELECT
        o.organ_id,
        o.organ_type,
        d.full_name AS donor_name,
        d.blood_group
    FROM organ o
    JOIN donor d ON o.donor_id = d.donor_id
    WHERE o.hospital_id=$hid
      AND o.availability_status='available'
      AND o.approval_status='accepted'
    ORDER BY o.date_added DESC, o.organ_id DESC
");
$o_arr = [];
while ($o = $avail_organs->fetch_assoc()) $o_arr[] = $o;

$confirmed_matches = $conn->query("
    SELECT
        m.match_id,
        r.full_name AS rec_name,
        o.organ_type,
        d.full_name AS donor_name
    FROM match_record m
    JOIN recipient r ON m.recipient_id = r.recipient_id
    JOIN organ o ON m.organ_id = o.organ_id
    JOIN donor d ON o.donor_id = d.donor_id
    LEFT JOIN transplant t ON t.organ_id = o.organ_id
    WHERE m.match_status='confirmed'
      AND r.hospital_id=$hid
      AND o.hospital_id=$hid
      AND t.transplant_id IS NULL
    ORDER BY m.matched_on DESC
");
$cm_arr = [];
while ($cm = $confirmed_matches->fetch_assoc()) $cm_arr[] = $cm;

$transplants = $conn->query("
    SELECT
        t.*,
        d.full_name AS donor_name,
        d.blood_group AS donor_blood,
        r.full_name AS rec_name,
        r.blood_group AS rec_blood,
        o.organ_type
    FROM transplant t
    JOIN donor d ON t.donor_id = d.donor_id
    JOIN recipient r ON t.recipient_id = r.recipient_id
    JOIN organ o ON t.organ_id = o.organ_id
    WHERE t.hospital_id=$hid
    ORDER BY t.transplant_date DESC, t.transplant_id DESC
");
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Matches & Transplants — Hospital</title>
<link rel="stylesheet" href="../css/style.css">
</head>
<body>
<div class="wrapper">
<?php renderSidebar('hospital','matches.php'); ?>

<div class="main-content">
    <div class="topbar">
        <h1>🔗 Matches & Transplants</h1>
        <div class="topbar-right">
            <button class="btn btn-primary btn-sm" onclick="document.getElementById('matchModal').style.display='flex'">+ Create Match</button>
            <button class="btn btn-success btn-sm" onclick="document.getElementById('transplantModal').style.display='flex'">+ Record Transplant</button>
        </div>
    </div>

    <div class="page-body">
        <?php if ($msg): ?>
            <div class="alert alert-success"><?= htmlspecialchars($msg) ?></div>
        <?php endif; ?>

        <?php if ($err): ?>
            <div class="alert alert-danger"><?= htmlspecialchars($err) ?></div>
        <?php endif; ?>

        <div class="card">
            <div class="card-title">🔗 Match Records</div>
            <div class="table-wrap">
                <table>
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Recipient</th>
                            <th>Organ Needed</th>
                            <th>Matched Organ</th>
                            <th>Donor</th>
                            <th>Blood Match</th>
                            <th>Date</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php if ($matches->num_rows === 0): ?>
                        <tr>
                            <td colspan="9" style="text-align:center;color:#64748b;padding:30px">
                                No match records found.
                            </td>
                        </tr>
                    <?php else: ?>
                        <?php while ($m = $matches->fetch_assoc()): ?>
                        <tr>
                            <td><?= $m['match_id'] ?></td>
                            <td>
                                <b><?= htmlspecialchars($m['rec_name']) ?></b><br>
                                <small>
                                    <?= htmlspecialchars($m['rec_blood']) ?> ·
                                    <?= htmlspecialchars($m['urgency_level']) ?>
                                </small>
                            </td>
                            <td><?= htmlspecialchars($m['needed_organ_type']) ?></td>
                            <td><?= htmlspecialchars($m['organ_type']) ?></td>
                            <td>
                                <?= htmlspecialchars($m['donor_name']) ?><br>
                                <small><?= htmlspecialchars($m['donor_blood']) ?></small>
                            </td>
                            <td>
                                <?php $bm = $m['rec_blood'] === $m['donor_blood']; ?>
                                <span class="badge <?= $bm ? 'badge-success' : 'badge-warning' ?>">
                                    <?= $bm ? '✓ Match' : '⚠ Different' ?>
                                </span>
                            </td>
                            <td><?= date('M d, Y', strtotime($m['matched_on'])) ?></td>
                            <td>
                                <?php $sc = ['pending'=>'badge-warning','confirmed'=>'badge-success','rejected'=>'badge-danger']; ?>
                                <span class="badge <?= $sc[$m['match_status']] ?? 'badge-secondary' ?>">
                                    <?= ucfirst($m['match_status']) ?>
                                </span>
                            </td>
                            <td>
                                <?php if ($m['match_status'] === 'pending'): ?>
                                    <form method="POST" style="display:inline">
                                        <input type="hidden" name="action" value="confirm">
                                        <input type="hidden" name="match_id" value="<?= $m['match_id'] ?>">
                                        <button type="submit" class="btn btn-sm btn-success">Confirm</button>
                                    </form>

                                    <form method="POST" style="display:inline">
                                        <input type="hidden" name="action" value="reject_match">
                                        <input type="hidden" name="match_id" value="<?= $m['match_id'] ?>">
                                        <button type="submit" class="btn btn-sm btn-danger" onclick="return confirm('Reject this match?')">Reject</button>
                                    </form>
                                <?php elseif ($m['match_status'] === 'confirmed'): ?>
                                    <span style="color:#16a34a;font-size:12px;font-weight:600">Ready for transplant</span>
                                <?php else: ?>
                                    <span style="color:#64748b;font-size:12px">Closed</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <div class="card">
            <div class="card-title">✅ Transplant History</div>
            <div class="table-wrap">
                <table>
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Donor</th>
                            <th>Recipient</th>
                            <th>Organ</th>
                            <th>Date</th>
                            <th>Status</th>
                            <th>Notes</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php if ($transplants->num_rows === 0): ?>
                        <tr>
                            <td colspan="7" style="text-align:center;color:#64748b;padding:30px">
                                No transplant records found.
                            </td>
                        </tr>
                    <?php else: ?>
                        <?php while ($t = $transplants->fetch_assoc()): ?>
                        <tr>
                            <td><?= $t['transplant_id'] ?></td>
                            <td>
                                <?= htmlspecialchars($t['donor_name']) ?><br>
                                <small><?= htmlspecialchars($t['donor_blood']) ?></small>
                            </td>
                            <td>
                                <?= htmlspecialchars($t['rec_name']) ?><br>
                                <small><?= htmlspecialchars($t['rec_blood']) ?></small>
                            </td>
                            <td><?= htmlspecialchars($t['organ_type']) ?></td>
                            <td><?= date('M d, Y', strtotime($t['transplant_date'])) ?></td>
                            <td><span class="badge badge-success"><?= htmlspecialchars($t['status']) ?></span></td>
                            <td><small><?= htmlspecialchars($t['notes']) ?></small></td>
                        </tr>
                        <?php endwhile; ?>
                    <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
</div>

<!-- Match Modal -->
<div id="matchModal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.5);z-index:999;align-items:center;justify-content:center">
    <div style="background:#fff;border-radius:16px;padding:32px;width:520px;max-height:90vh;overflow-y:auto;position:relative">
        <button onclick="document.getElementById('matchModal').style.display='none'" style="position:absolute;top:16px;right:16px;background:none;border:none;font-size:20px;cursor:pointer">✕</button>
        <h3 style="margin-bottom:20px">Create Match</h3>

        <form method="POST">
            <input type="hidden" name="action" value="add_match">

            <div class="form-group">
                <label>Recipient (Waiting)</label>
                <select name="recipient_id" class="form-control" required>
                    <option value="">Select</option>
                    <?php foreach ($r_arr as $r): ?>
                        <option value="<?= $r['recipient_id'] ?>">
                            <?= htmlspecialchars($r['full_name']) ?> — <?= htmlspecialchars($r['blood_group']) ?> — needs <?= htmlspecialchars($r['needed_organ_type']) ?> — <?= htmlspecialchars($r['urgency_level']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="form-group">
                <label>Accepted Available Organ</label>
                <select name="organ_id" class="form-control" required>
                    <option value="">Select</option>
                    <?php foreach ($o_arr as $o): ?>
                        <option value="<?= $o['organ_id'] ?>">
                            <?= htmlspecialchars($o['organ_type']) ?> from <?= htmlspecialchars($o['donor_name']) ?> (<?= htmlspecialchars($o['blood_group']) ?>)
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <button type="submit" class="btn btn-primary" style="width:100%">Create Match</button>
        </form>
    </div>
</div>

<!-- Transplant Modal -->
<div id="transplantModal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.5);z-index:999;align-items:center;justify-content:center">
    <div style="background:#fff;border-radius:16px;padding:32px;width:520px;max-height:90vh;overflow-y:auto;position:relative">
        <button onclick="document.getElementById('transplantModal').style.display='none'" style="position:absolute;top:16px;right:16px;background:none;border:none;font-size:20px;cursor:pointer">✕</button>
        <h3 style="margin-bottom:20px">Record Transplant</h3>

        <form method="POST">
            <input type="hidden" name="action" value="add_transplant">

            <div class="form-group">
                <label>Confirmed Match</label>
                <select name="match_id" class="form-control" required>
                    <option value="">Select</option>
                    <?php foreach ($cm_arr as $cm): ?>
                        <option value="<?= $cm['match_id'] ?>">
                            Match #<?= $cm['match_id'] ?> — <?= htmlspecialchars($cm['rec_name']) ?> — <?= htmlspecialchars($cm['organ_type']) ?> — Donor: <?= htmlspecialchars($cm['donor_name']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="form-group">
                <label>Transplant Date</label>
                <input type="date" name="transplant_date" class="form-control" value="<?= date('Y-m-d') ?>" required>
            </div>

            <div class="form-group">
                <label>Status</label>
                <input type="text" name="status" class="form-control" value="Successful" required>
            </div>

            <div class="form-group">
                <label>Notes</label>
                <textarea name="notes" class="form-control" rows="3" placeholder="Optional notes"></textarea>
            </div>

            <button type="submit" class="btn btn-success" style="width:100%">Record Transplant</button>
        </form>
    </div>
</div>

</body>
</html>