<?php
session_start();
require_once '../includes/auth.php';
require_once '../includes/config.php';
require_once '../includes/sidebar.php';
requireHospital();

$hid = $_SESSION['hospital_id'];

$stats = [
    'pending_review' => $conn->query("
        SELECT COUNT(*) c
        FROM organ
        WHERE approval_status='pending'
    ")->fetch_assoc()['c'],

    'accepted_organs' => $conn->query("
        SELECT COUNT(*) c
        FROM organ
        WHERE hospital_id=$hid
          AND approval_status='accepted'
          AND availability_status='available'
    ")->fetch_assoc()['c'],

    'rejected_organs' => $conn->query("
        SELECT COUNT(*) c
        FROM organ
        WHERE reviewed_by_hospital_id=$hid
          AND approval_status='rejected'
    ")->fetch_assoc()['c'],

    'recipients' => $conn->query("
        SELECT COUNT(*) c
        FROM recipient
        WHERE hospital_id=$hid
    ")->fetch_assoc()['c'],

    'matched' => $conn->query("
        SELECT COUNT(*) c
        FROM recipient
        WHERE hospital_id=$hid
          AND status='matched'
    ")->fetch_assoc()['c'],

    'transplants' => $conn->query("
        SELECT COUNT(*) c
        FROM transplant
        WHERE hospital_id=$hid
    ")->fetch_assoc()['c'],
];

$organs = $conn->query("
    SELECT o.*, d.full_name AS donor_name, d.blood_group
    FROM organ o
    JOIN donor d ON o.donor_id = d.donor_id
    WHERE o.hospital_id = $hid
      AND o.approval_status = 'accepted'
    ORDER BY o.date_added DESC
    LIMIT 6
");

$recipients = $conn->query("
    SELECT *
    FROM recipient
    WHERE hospital_id = $hid
    ORDER BY FIELD(urgency_level,'Critical','High','Medium','Low')
    LIMIT 6
");
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta http-equiv="refresh" content="20">
<title>Hospital Dashboard — OrganMS</title>
<link rel="stylesheet" href="../css/style.css">
</head>
<body>
<div class="wrapper">
<?php renderSidebar('hospital','dashboard.php'); ?>

<div class="main-content">
    <div class="topbar">
        <h1>📊 Hospital Dashboard</h1>
        <div class="topbar-right">
            <span><span class="live-dot"></span>Live</span>
            <span class="user-badge">🏥 <?= htmlspecialchars($_SESSION['name']) ?></span>
        </div>
    </div>

    <div class="page-body">

        <div class="stats-grid">
            <div class="stat-card">
                <div class="stat-icon">⏳</div>
                <div class="stat-value"><?= $stats['pending_review'] ?></div>
                <div class="stat-label">Pending Review</div>
            </div>

            <div class="stat-card">
                <div class="stat-icon">🫁</div>
                <div class="stat-value"><?= $stats['accepted_organs'] ?></div>
                <div class="stat-label">Accepted Available Organs</div>
            </div>

            <div class="stat-card">
                <div class="stat-icon">❌</div>
                <div class="stat-value"><?= $stats['rejected_organs'] ?></div>
                <div class="stat-label">Rejected Requests</div>
            </div>

            <div class="stat-card">
                <div class="stat-icon">🧑‍⚕️</div>
                <div class="stat-value"><?= $stats['recipients'] ?></div>
                <div class="stat-label">My Recipients</div>
            </div>

            <div class="stat-card">
                <div class="stat-icon">🔗</div>
                <div class="stat-value"><?= $stats['matched'] ?></div>
                <div class="stat-label">Matched</div>
            </div>

            <div class="stat-card">
                <div class="stat-icon">✅</div>
                <div class="stat-value"><?= $stats['transplants'] ?></div>
                <div class="stat-label">Transplants Done</div>
            </div>
        </div>

        <div style="display:grid;grid-template-columns:1fr 1fr;gap:20px">
            <div class="card">
                <div class="card-title"><span class="live-dot"></span>🫁 Accepted Organ Stock</div>
                <table>
                    <thead>
                        <tr>
                            <th>Organ</th>
                            <th>Donor</th>
                            <th>Blood</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php if ($organs->num_rows === 0): ?>
                        <tr>
                            <td colspan="4" style="text-align:center;color:#64748b;padding:24px">
                                No accepted organs yet.
                            </td>
                        </tr>
                    <?php else: ?>
                        <?php while ($o = $organs->fetch_assoc()): ?>
                        <tr>
                            <td><b><?= htmlspecialchars($o['organ_type']) ?></b></td>
                            <td><?= htmlspecialchars($o['donor_name']) ?></td>
                            <td><span class="badge badge-info"><?= htmlspecialchars($o['blood_group']) ?></span></td>
                            <td>
                                <?php
                                $sc = [
                                    'available' => 'badge-success',
                                    'matched' => 'badge-warning',
                                    'used' => 'badge-secondary'
                                ];
                                ?>
                                <span class="badge <?= $sc[$o['availability_status']] ?>">
                                    <?= ucfirst($o['availability_status']) ?>
                                </span>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    <?php endif; ?>
                    </tbody>
                </table>

                <a href="organ_stock.php" class="btn btn-outline btn-sm" style="margin-top:12px">Review & View All →</a>
            </div>

            <div class="card">
                <div class="card-title">🧑‍⚕️ Recipients (by Urgency)</div>
                <table>
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>Organ Needed</th>
                            <th>Urgency</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php if ($recipients->num_rows === 0): ?>
                        <tr>
                            <td colspan="4" style="text-align:center;color:#64748b;padding:24px">
                                No recipients found.
                            </td>
                        </tr>
                    <?php else: ?>
                        <?php while ($r = $recipients->fetch_assoc()): ?>
                        <tr>
                            <td><?= htmlspecialchars($r['full_name']) ?></td>
                            <td><?= htmlspecialchars($r['needed_organ_type']) ?></td>
                            <td><span class="urgency-<?= $r['urgency_level'] ?>"><?= $r['urgency_level'] ?></span></td>
                            <td>
                                <?php
                                $sc = [
                                    'waiting' => 'badge-warning',
                                    'matched' => 'badge-info',
                                    'transplanted' => 'badge-success'
                                ];
                                ?>
                                <span class="badge <?= $sc[$r['status']] ?>">
                                    <?= ucfirst($r['status']) ?>
                                </span>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    <?php endif; ?>
                    </tbody>
                </table>

                <a href="recipients.php" class="btn btn-outline btn-sm" style="margin-top:12px">Manage Recipients →</a>
            </div>
        </div>

    </div>
</div>
</div>
</body>
</html>