<?php
session_start();
require_once '../includes/auth.php';
require_once '../includes/config.php';
require_once '../includes/sidebar.php';
requireHospital();

$hid = $_SESSION['hospital_id'];

$filter_bg = sanitize($conn, $_GET['blood_group'] ?? '');
$filter_organ = sanitize($conn, $_GET['organ_type'] ?? '');
$filter_status = sanitize($conn, $_GET['approval_status'] ?? '');

$where = "d.eligibility_status='eligible'";

if ($filter_bg !== '') {
    $where .= " AND d.blood_group='$filter_bg'";
}

if ($filter_organ !== '') {
    $where .= " AND o.organ_type='$filter_organ'";
}

if ($filter_status !== '') {
    if ($filter_status === 'pending') {
        $where .= " AND o.approval_status='pending' AND (o.hospital_id IS NULL OR o.hospital_id=$hid)";
    } elseif ($filter_status === 'accepted') {
        $where .= " AND o.approval_status='accepted' AND o.hospital_id=$hid";
    } elseif ($filter_status === 'rejected') {
        $where .= " AND o.approval_status='rejected' AND o.reviewed_by_hospital_id=$hid";
    }
} else {
    $where .= " AND (
        (o.approval_status='pending' AND (o.hospital_id IS NULL OR o.hospital_id=$hid))
        OR
        (o.approval_status='accepted' AND o.hospital_id=$hid)
        OR
        (o.approval_status='rejected' AND o.reviewed_by_hospital_id=$hid)
    )";
}

$donors = $conn->query("
    SELECT
        d.donor_id,
        d.full_name,
        d.gender,
        d.blood_group,
        d.phone,
        d.address,
        d.medical_status,
        d.eligibility_status,
        o.organ_id,
        o.organ_type,
        o.approval_status,
        o.availability_status,
        o.rejection_reason,
        o.date_added
    FROM donor d
    LEFT JOIN organ o ON d.donor_id = o.donor_id
    WHERE $where
    ORDER BY
        FIELD(o.approval_status, 'pending', 'accepted', 'rejected'),
        d.full_name,
        o.date_added DESC
");
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Donors & Organ Requests — Hospital</title>
<link rel="stylesheet" href="../css/style.css">
</head>
<body>
<div class="wrapper">
<?php renderSidebar('hospital', 'donors.php'); ?>

<div class="main-content">
<div class="topbar">
    <h1>💉 Donors & Organ Requests</h1>
</div>

<div class="page-body">

    <div class="card">
        <form method="GET" style="display:flex;gap:12px;align-items:flex-end;flex-wrap:wrap">
            <div class="form-group" style="margin:0">
                <label>Blood Group</label>
                <select name="blood_group" class="form-control" style="width:120px">
                    <option value="">All</option>
                    <?php foreach (['A+','A-','B+','B-','O+','O-','AB+','AB-'] as $bg): ?>
                        <option value="<?= $bg ?>" <?= $filter_bg === $bg ? 'selected' : '' ?>><?= $bg ?></option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="form-group" style="margin:0">
                <label>Organ Type</label>
                <select name="organ_type" class="form-control" style="width:150px">
                    <option value="">All</option>
                    <?php foreach (['Kidney','Liver','Heart','Lung','Cornea','Pancreas','Intestine','Bone Marrow'] as $t): ?>
                        <option value="<?= $t ?>" <?= $filter_organ === $t ? 'selected' : '' ?>><?= $t ?></option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="form-group" style="margin:0">
                <label>Approval Status</label>
                <select name="approval_status" class="form-control" style="width:140px">
                    <option value="">All Relevant</option>
                    <option value="pending" <?= $filter_status === 'pending' ? 'selected' : '' ?>>Pending</option>
                    <option value="accepted" <?= $filter_status === 'accepted' ? 'selected' : '' ?>>Accepted</option>
                    <option value="rejected" <?= $filter_status === 'rejected' ? 'selected' : '' ?>>Rejected</option>
                </select>
            </div>

            <button type="submit" class="btn btn-primary">Filter</button>
            <a href="donors.php" class="btn btn-secondary">Clear</a>
        </form>
    </div>

    <div class="card">
        <div class="card-title">📋 Donor Organ Records</div>

        <div class="table-wrap">
            <table>
                <thead>
                    <tr>
                        <th>Donor ID</th>
                        <th>Donor Name</th>
                        <th>Blood</th>
                        <th>Gender</th>
                        <th>Location</th>
                        <th>Organ</th>
                        <th>Approval</th>
                        <th>Availability</th>
                        <th>Reason</th>
                        <th>Contact</th>
                        <th>Pay Donor</th>
                    </tr>
                </thead>
                <tbody>
                <?php if ($donors && $donors->num_rows > 0): ?>
                    <?php while ($d = $donors->fetch_assoc()): ?>
                    <tr>
                        <td><?= $d['donor_id'] ?></td>
                        <td>
                            <b><?= htmlspecialchars($d['full_name']) ?></b><br>
                            <small style="color:#64748b"><?= htmlspecialchars($d['medical_status']) ?></small>
                        </td>
                        <td><span class="badge badge-info"><?= htmlspecialchars($d['blood_group']) ?></span></td>
                        <td><?= htmlspecialchars($d['gender']) ?></td>
                        <td><?= htmlspecialchars($d['address']) ?></td>
                        <td>
                            <?php if ($d['organ_id']): ?>
                                <span class="badge badge-success"><?= htmlspecialchars($d['organ_type']) ?></span>
                            <?php else: ?>
                                <span class="badge badge-secondary">No organ</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php
                            $approvalClass = [
                                'pending' => 'badge-warning',
                                'accepted' => 'badge-success',
                                'rejected' => 'badge-danger'
                            ];
                            ?>
                            <?php if ($d['approval_status']): ?>
                                <span class="badge <?= $approvalClass[$d['approval_status']] ?? 'badge-secondary' ?>">
                                    <?= ucfirst($d['approval_status']) ?>
                                </span>
                            <?php else: ?>
                                <span class="badge badge-secondary">—</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php
                            $statusClass = [
                                'available' => 'badge-success',
                                'matched' => 'badge-warning',
                                'used' => 'badge-secondary'
                            ];
                            ?>
                            <?php if ($d['availability_status']): ?>
                                <span class="badge <?= $statusClass[$d['availability_status']] ?? 'badge-secondary' ?>">
                                    <?= ucfirst($d['availability_status']) ?>
                                </span>
                            <?php else: ?>
                                <span class="badge badge-secondary">—</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?= htmlspecialchars($d['rejection_reason'] ?? '—') ?>
                        </td>
                        <td>
                            <a href="tel:<?= htmlspecialchars($d['phone']) ?>" class="btn btn-sm btn-primary">
                                📞 <?= htmlspecialchars($d['phone']) ?>
                            </a>
                        </td>
                        <td>
                            <?php if ($d['approval_status'] === 'accepted'): ?>
                                <a href="pay_donor.php?donor_id=<?= $d['donor_id'] ?>" class="btn btn-sm btn-success">💸 Pay</a>
                            <?php else: ?>
                                <span style="color:#94a3b8;font-size:12px">Not accepted</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="11" style="text-align:center;color:#64748b;padding:30px">
                            No donor organ records found.
                        </td>
                    </tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

</div>
</div>
</div>
</body>
</html>