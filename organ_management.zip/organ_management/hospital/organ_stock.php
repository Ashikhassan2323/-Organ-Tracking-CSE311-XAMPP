<?php
session_start();
require_once '../includes/auth.php';
require_once '../includes/config.php';
require_once '../includes/sidebar.php';
requireHospital();

$hid = $_SESSION['hospital_id'];
$msg = '';
$err = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $oid = isset($_POST['organ_id']) ? (int)$_POST['organ_id'] : 0;

    if ($oid <= 0) {
        $err = "Invalid organ selected.";
    } else {
        if ($action === 'accept') {
            $sql = "UPDATE organ
                    SET approval_status='accepted',
                        hospital_id=$hid,
                        reviewed_by_hospital_id=$hid,
                        reviewed_at=NOW(),
                        rejection_reason=NULL
                    WHERE organ_id=$oid";

            if ($conn->query($sql)) {
                $msg = "Organ accepted successfully.";
            } else {
                $err = "Failed to accept organ: " . $conn->error;
            }

        } elseif ($action === 'reject') {
            $reason = sanitize($conn, $_POST['rejection_reason'] ?? '');
            if ($reason === '') {
                $reason = 'Rejected by hospital';
            }

            $sql = "UPDATE organ
                    SET approval_status='rejected',
                        reviewed_by_hospital_id=$hid,
                        reviewed_at=NOW(),
                        rejection_reason='$reason'
                    WHERE organ_id=$oid";

            if ($conn->query($sql)) {
                $msg = "Organ rejected.";
            } else {
                $err = "Failed to reject organ: " . $conn->error;
            }
        }
    }
}

$pending_organs = $conn->query("
    SELECT
        o.*,
        d.full_name AS donor_name,
        d.blood_group,
        d.phone AS donor_phone
    FROM organ o
    JOIN donor d ON o.donor_id = d.donor_id
    WHERE o.approval_status = 'pending'
    ORDER BY o.date_added DESC
");

$accepted_organs = $conn->query("
    SELECT
        o.*,
        d.full_name AS donor_name,
        d.blood_group,
        d.phone AS donor_phone
    FROM organ o
    JOIN donor d ON o.donor_id = d.donor_id
    WHERE o.approval_status = 'accepted'
      AND o.hospital_id = $hid
    ORDER BY o.date_added DESC
");

$rejected_organs = $conn->query("
    SELECT
        o.*,
        d.full_name AS donor_name,
        d.blood_group,
        d.phone AS donor_phone
    FROM organ o
    JOIN donor d ON o.donor_id = d.donor_id
    WHERE o.approval_status = 'rejected'
      AND o.reviewed_by_hospital_id = $hid
    ORDER BY o.reviewed_at DESC, o.date_added DESC
");
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta http-equiv="refresh" content="20">
<title>Organ Review & Stock — Hospital</title>
<link rel="stylesheet" href="../css/style.css">
</head>
<body>
<div class="wrapper">
<?php renderSidebar('hospital', 'organ_stock.php'); ?>

<div class="main-content">
    <div class="topbar">
        <h1>🫁 Organ Review & Stock</h1>
        <div class="topbar-right">
            <span><span class="live-dot"></span>Updates every 20s</span>
        </div>
    </div>

    <div class="page-body">
        <?php if ($msg): ?>
            <div class="alert alert-success"><?= htmlspecialchars($msg) ?></div>
        <?php endif; ?>

        <?php if ($err): ?>
            <div class="alert alert-danger"><?= htmlspecialchars($err) ?></div>
        <?php endif; ?>

        <div class="card">
            <div class="card-title">⏳ Pending Organ Requests</div>
            <div class="table-wrap">
                <table>
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Organ</th>
                            <th>Donor</th>
                            <th>Phone</th>
                            <th>Blood Group</th>
                            <th>Date Added</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php if ($pending_organs->num_rows === 0): ?>
                        <tr>
                            <td colspan="7" style="text-align:center;color:#64748b;padding:30px">
                                No pending organs for review.
                            </td>
                        </tr>
                    <?php else: ?>
                        <?php while ($o = $pending_organs->fetch_assoc()): ?>
                        <tr>
                            <td><?= $o['organ_id'] ?></td>
                            <td><b><?= htmlspecialchars($o['organ_type']) ?></b></td>
                            <td><?= htmlspecialchars($o['donor_name']) ?></td>
                            <td>
                                <a href="tel:<?= htmlspecialchars($o['donor_phone']) ?>">
                                    <?= htmlspecialchars($o['donor_phone']) ?>
                                </a>
                            </td>
                            <td><span class="badge badge-info"><?= htmlspecialchars($o['blood_group']) ?></span></td>
                            <td><?= date('M d, Y H:i', strtotime($o['date_added'])) ?></td>
                            <td>
                                <form method="POST" style="display:inline">
                                    <input type="hidden" name="organ_id" value="<?= $o['organ_id'] ?>">
                                    <input type="hidden" name="action" value="accept">
                                    <button type="submit" class="btn btn-sm btn-success">✓ Accept</button>
                                </form>

                                <form method="POST" style="display:inline">
                                    <input type="hidden" name="organ_id" value="<?= $o['organ_id'] ?>">
                                    <input type="hidden" name="action" value="reject">
                                    <input type="text" name="rejection_reason" class="form-control" placeholder="Reason" style="width:120px;display:inline;padding:4px 6px;font-size:12px">
                                    <button type="submit" class="btn btn-sm btn-danger">✕ Reject</button>
                                </form>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <div class="card">
            <div class="card-title">✅ Accepted Organ Stock</div>
            <div class="table-wrap">
                <table>
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Organ</th>
                            <th>Donor</th>
                            <th>Phone</th>
                            <th>Blood Group</th>
                            <th>Availability</th>
                            <th>Accepted On</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php if ($accepted_organs->num_rows === 0): ?>
                        <tr>
                            <td colspan="7" style="text-align:center;color:#64748b;padding:30px">
                                No accepted organs yet.
                            </td>
                        </tr>
                    <?php else: ?>
                        <?php while ($o = $accepted_organs->fetch_assoc()): ?>
                        <tr>
                            <td><?= $o['organ_id'] ?></td>
                            <td><b><?= htmlspecialchars($o['organ_type']) ?></b></td>
                            <td><?= htmlspecialchars($o['donor_name']) ?></td>
                            <td>
                                <a href="tel:<?= htmlspecialchars($o['donor_phone']) ?>">
                                    <?= htmlspecialchars($o['donor_phone']) ?>
                                </a>
                            </td>
                            <td><span class="badge badge-info"><?= htmlspecialchars($o['blood_group']) ?></span></td>
                            <td>
                                <?php
                                $sc = [
                                    'available' => 'badge-success',
                                    'matched' => 'badge-warning',
                                    'used' => 'badge-secondary'
                                ];
                                ?>
                                <span class="badge <?= $sc[$o['availability_status']] ?? 'badge-secondary' ?>">
                                    <?= ucfirst($o['availability_status']) ?>
                                </span>
                            </td>
                            <td><?= $o['reviewed_at'] ? date('M d, Y H:i', strtotime($o['reviewed_at'])) : '—' ?></td>
                        </tr>
                        <?php endwhile; ?>
                    <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <div class="card">
            <div class="card-title">❌ Rejected Organ Requests</div>
            <div class="table-wrap">
                <table>
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Organ</th>
                            <th>Donor</th>
                            <th>Blood Group</th>
                            <th>Rejected On</th>
                            <th>Reason</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php if ($rejected_organs->num_rows === 0): ?>
                        <tr>
                            <td colspan="6" style="text-align:center;color:#64748b;padding:30px">
                                No rejected organ requests.
                            </td>
                        </tr>
                    <?php else: ?>
                        <?php while ($o = $rejected_organs->fetch_assoc()): ?>
                        <tr>
                            <td><?= $o['organ_id'] ?></td>
                            <td><b><?= htmlspecialchars($o['organ_type']) ?></b></td>
                            <td><?= htmlspecialchars($o['donor_name']) ?></td>
                            <td><span class="badge badge-info"><?= htmlspecialchars($o['blood_group']) ?></span></td>
                            <td><?= $o['reviewed_at'] ? date('M d, Y H:i', strtotime($o['reviewed_at'])) : '—' ?></td>
                            <td><?= htmlspecialchars($o['rejection_reason'] ?? '—') ?></td>
                        </tr>
                        <?php endwhile; ?>
                    <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

    </div>
</div>
</div>
</body>
</html>