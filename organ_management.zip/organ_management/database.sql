CREATE DATABASE IF NOT EXISTS organ_management;
USE organ_management;

SET FOREIGN_KEY_CHECKS = 0;
DROP TABLE IF EXISTS payments;
DROP TABLE IF EXISTS transplant;
DROP TABLE IF EXISTS match_record;
DROP TABLE IF EXISTS organ;
DROP TABLE IF EXISTS recipient;
DROP TABLE IF EXISTS donor;
DROP TABLE IF EXISTS hospital;
DROP TABLE IF EXISTS admin;
SET FOREIGN_KEY_CHECKS = 1;

CREATE TABLE admin (
    admin_id INT AUTO_INCREMENT PRIMARY KEY,
    full_name VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    username VARCHAR(50) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    phone VARCHAR(20)
);

CREATE TABLE hospital (
    hospital_id INT AUTO_INCREMENT PRIMARY KEY,
    hospital_name VARCHAR(100) NOT NULL,
    city VARCHAR(50),
    address TEXT,
    phone VARCHAR(20),
    email VARCHAR(100),
    password_hash VARCHAR(255) NOT NULL,
    registration_no VARCHAR(50) UNIQUE,
    subscription_status ENUM('pending','active','expired') DEFAULT 'pending',
    bkash_transaction_id VARCHAR(100),
    subscription_paid_at TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE donor (
    donor_id INT AUTO_INCREMENT PRIMARY KEY,
    full_name VARCHAR(100) NOT NULL,
    gender VARCHAR(10),
    date_of_birth DATE,
    blood_group VARCHAR(5),
    phone VARCHAR(20) UNIQUE NOT NULL,
    address TEXT,
    medical_status VARCHAR(100) DEFAULT 'Pending Review',
    eligibility_status ENUM('pending','eligible','ineligible') DEFAULT 'pending',
    password_hash VARCHAR(255) NOT NULL,
    payment_status ENUM('none','paid') DEFAULT 'none',
    payment_amount DECIMAL(10,2) DEFAULT 0.00,
    paid_by_hospital_id INT NULL,
    registration_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE recipient (
    recipient_id INT AUTO_INCREMENT PRIMARY KEY,
    full_name VARCHAR(100) NOT NULL,
    gender VARCHAR(10),
    date_of_birth DATE,
    blood_group VARCHAR(5),
    phone VARCHAR(20),
    address TEXT,
    needed_organ_type VARCHAR(50),
    urgency_level ENUM('Low','Medium','High','Critical') DEFAULT 'Medium',
    status ENUM('waiting','matched','transplanted') DEFAULT 'waiting',
    hospital_id INT,
    registration_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (hospital_id) REFERENCES hospital(hospital_id) ON DELETE SET NULL
);

CREATE TABLE organ (
    organ_id INT AUTO_INCREMENT PRIMARY KEY,
    donor_id INT NOT NULL,
    hospital_id INT NULL,
    organ_type VARCHAR(50) NOT NULL,
    availability_status ENUM('available','matched','used') DEFAULT 'available',
    date_added TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (donor_id) REFERENCES donor(donor_id) ON DELETE RESTRICT ON UPDATE CASCADE,
    FOREIGN KEY (hospital_id) REFERENCES hospital(hospital_id) ON DELETE SET NULL ON UPDATE CASCADE
);

CREATE TABLE match_record (
    match_id INT AUTO_INCREMENT PRIMARY KEY,
    recipient_id INT NOT NULL,
    organ_id INT NOT NULL,
    matched_on TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    match_status ENUM('pending','confirmed','rejected') DEFAULT 'pending',
    FOREIGN KEY (recipient_id) REFERENCES recipient(recipient_id),
    FOREIGN KEY (organ_id) REFERENCES organ(organ_id)
);

CREATE TABLE transplant (
    transplant_id INT AUTO_INCREMENT PRIMARY KEY,
    donor_id INT NOT NULL,
    recipient_id INT NOT NULL,
    organ_id INT NOT NULL,
    hospital_id INT NULL,
    transplant_date DATE,
    status VARCHAR(30),
    notes TEXT,
    FOREIGN KEY (donor_id) REFERENCES donor(donor_id) ON DELETE RESTRICT,
    FOREIGN KEY (recipient_id) REFERENCES recipient(recipient_id) ON DELETE RESTRICT,
    FOREIGN KEY (organ_id) REFERENCES organ(organ_id) ON DELETE RESTRICT,
    FOREIGN KEY (hospital_id) REFERENCES hospital(hospital_id) ON DELETE SET NULL
);

CREATE TABLE payments (
    payment_id INT AUTO_INCREMENT PRIMARY KEY,
    payer_type ENUM('hospital','hospital_to_donor') NOT NULL,
    hospital_id INT,
    donor_id INT,
    amount DECIMAL(10,2) NOT NULL,
    bkash_transaction_id VARCHAR(100),
    payment_status ENUM('pending','verified','rejected') DEFAULT 'pending',
    purpose VARCHAR(100),
    payment_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    verified_by_admin INT,
    FOREIGN KEY (hospital_id) REFERENCES hospital(hospital_id) ON DELETE SET NULL,
    FOREIGN KEY (donor_id) REFERENCES donor(donor_id) ON DELETE SET NULL,
    FOREIGN KEY (verified_by_admin) REFERENCES admin(admin_id) ON DELETE SET NULL
);

-- SEED DATA

-- Admin: username=admin, password=admin
INSERT INTO admin (full_name, email, username, password_hash, phone) VALUES
('System Administrator', 'admin@organms.com', 'admin', '$2y$12$rz7coi2nFnQSbqYnXBzh6ergqJCYdGV2COgI3YdTR9Z5waaC/GI3O', '01700000000');

-- Hospitals: password=hospital
INSERT INTO hospital (hospital_name, city, address, phone, email, password_hash, registration_no, subscription_status, bkash_transaction_id) VALUES
('Dhaka Medical College Hospital', 'Dhaka', 'Bakshibazar, Dhaka', '029661060', 'dmch@example.com', '$2y$12$vezHUOK2yMdN0NeFjvX2fOzJWnaKkie5oCuJ4/bUX0phjQjXRFpf.', 'REG-001', 'active', 'BKS-H-001'),
('Square Hospital', 'Dhaka', '18/F Bir Uttam Qazi Nuruzzaman Sarak, Dhaka', '09610601010', 'square@example.com', '$2y$12$vezHUOK2yMdN0NeFjvX2fOzJWnaKkie5oCuJ4/bUX0phjQjXRFpf.', 'REG-002', 'active', 'BKS-H-002'),
('United Hospital', 'Dhaka', 'Plot 15, Road 71, Gulshan, Dhaka', '09666771000', 'united@example.com', '$2y$12$vezHUOK2yMdN0NeFjvX2fOzJWnaKkie5oCuJ4/bUX0phjQjXRFpf.', 'REG-003', 'pending', NULL);

-- Donors: password=donor (phone or donor_id can be used as login ID)
INSERT INTO donor (full_name, gender, date_of_birth, blood_group, phone, address, medical_status, eligibility_status, password_hash) VALUES
('Rahim Ahmed', 'Male', '1995-03-10', 'A+', '01711111111', 'Dhaka', 'Fit', 'eligible', '$2y$12$w4yVVWl/qbkKhwm1x4j./.9DLFxPJxXr3/2U6CQspDr9ezFDvQM9y'),
('Nusrat Jahan', 'Female', '1991-07-21', 'B+', '01722222222', 'Chattogram', 'Fit', 'eligible', '$2y$12$w4yVVWl/qbkKhwm1x4j./.9DLFxPJxXr3/2U6CQspDr9ezFDvQM9y'),
('Sohan Karim', 'Male', '1988-11-05', 'O+', '01733333333', 'Rajshahi', 'Fit', 'eligible', '$2y$12$w4yVVWl/qbkKhwm1x4j./.9DLFxPJxXr3/2U6CQspDr9ezFDvQM9y');

INSERT INTO recipient (full_name, gender, date_of_birth, blood_group, phone, address, needed_organ_type, urgency_level, status, hospital_id) VALUES
('Mim Akter', 'Female', '1998-01-15', 'A+', '01811111111', 'Dhaka', 'Kidney', 'High', 'waiting', 1),
('Arif Hasan', 'Male', '1985-09-09', 'B+', '01822222222', 'Khulna', 'Liver', 'Critical', 'waiting', 2),
('Tania Sultana', 'Female', '1992-12-19', 'O+', '01833333333', 'Sylhet', 'Cornea', 'Medium', 'waiting', 1);

INSERT INTO organ (donor_id, hospital_id, organ_type, availability_status) VALUES
(1, 1, 'Kidney', 'available'),
(2, 2, 'Liver', 'available'),
(3, 3, 'Cornea', 'available');
