# 🫀 OrganMS — Hospital Organ Management System
### CSE311 Project | North South University

---

## 🚀 Setup Instructions

### Requirements
- XAMPP (PHP 7.4+ & MySQL 5.7+)
- Web browser

### Steps

1. **Copy project folder**
   - Place the `organ_management` folder into `C:/xampp/htdocs/`

2. **Import the database**
   - Start XAMPP → Start Apache & MySQL
   - Open: http://localhost/phpmyadmin
   - Click **Import** → Choose `organ_management/database.sql`
   - Click **Go**

3. **Open the system**
   - Go to: http://localhost/organ_management/

---

## 🔑 Demo Login Credentials

| Role | Login Field | Value | Password |
|------|------------|-------|----------|
| **Admin** | Username | `admin` | `admin` |
| **Hospital 1** | Registration No / Name | `REG-001` or `Dhaka Medical College Hospital` | `hospital` |
| **Hospital 2** | Registration No / Name | `REG-002` or `Square Hospital` | `hospital` |
| **Hospital 3** | Registration No / Name | `REG-003` or `United Hospital` | `hospital` *(pending — pay subscription first)* |
| **Donor 1** | Phone / Donor ID | `01711111111` or `1` | `donor` |
| **Donor 2** | Phone / Donor ID | `01722222222` or `2` | `donor` |
| **Donor 3** | Phone / Donor ID | `01733333333` or `3` | `donor` |
| **Viewer** | *(no login)* | Click Viewer | — |

---

## 👥 Role Access Guide

### 🔐 Admin
- Full CRUD on all modules
- Manage hospitals, donors, recipients, organs, matches, transplants
- Verify/reject bKash payments
- Activate hospital subscriptions

### 🏥 Hospital
- Login with Registration No + Password
- Must pay ৳5,000/year via bKash to activate account
- View own organ stock (live, auto-refresh)
- Manage recipients
- Browse and contact eligible donors
- Pay donors and submit bKash transaction IDs
- View match records

### 💉 Donor
- Register free (phone = login ID)
- View eligibility status and medical notes
- Register organs for donation
- View payment history from hospitals

### 👁️ Viewer (Public)
- No login needed
- See all active hospitals
- Live organ availability per hospital
- Auto-refreshes every 20 seconds
- Links to register as donor or hospital

---

## ✨ New Features (vs original proposal)

| Feature | Description |
|---------|-------------|
| Role-based login | Admin / Hospital / Donor / Viewer |
| Hospital subscription | bKash payment + admin verification |
| Hospital registration | Public self-registration form |
| Donor registration | Free public registration |
| Donor payment | Hospitals can pay donors via bKash |
| Live organ stock | Auto-refreshing viewer for public |
| Payment management | Admin verifies all bKash transactions |
| Match system | Admin creates matches, hospitals view them |
| Transplant records | Full history tracking |

---

## 🗃️ Database Tables

| Table | Purpose |
|-------|---------|
| `admin` | System administrators |
| `hospital` | Registered hospitals + subscription status |
| `donor` | Organ donors |
| `recipient` | Organ recipients |
| `organ` | Available organs linked to donors |
| `match_record` | Donor-recipient matches |
| `transplant` | Completed transplant history |
| `payments` | bKash payment records (hospital subscriptions + donor payments) |

---

## 🛠️ Tech Stack
- **Backend:** PHP 7.4+
- **Database:** MySQL (via XAMPP)
- **Frontend:** HTML5, CSS3, vanilla JavaScript
- **No external frameworks** (pure PHP + CSS)

---

*Built for CSE311 Database Systems · North South University*
