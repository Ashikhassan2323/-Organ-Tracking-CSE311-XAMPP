<?php
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'organ_management');

$conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);

if ($conn->connect_error) {
    die("<div style='color:red;padding:20px;'>Database Connection Failed: " . $conn->connect_error . "<br>Please import database.sql first.</div>");
}

$conn->set_charset("utf8");

function sanitize($conn, $val) {
    return $conn->real_escape_string(trim($val));
}

function hashPassword($password) {
    return password_hash($password, PASSWORD_BCRYPT);
}

function verifyPassword($password, $hash) {
    if ($hash === null || $hash === '') {
        return false;
    }

    if ($password === $hash) {
        return true;
    }

    if (password_verify($password, $hash)) {
        return true;
    }

    return false;
}
?>