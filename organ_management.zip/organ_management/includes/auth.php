<?php
if (session_status() === PHP_SESSION_NONE) session_start();

function isAdmin() { return isset($_SESSION['role']) && $_SESSION['role'] === 'admin'; }
function isHospital() { return isset($_SESSION['role']) && $_SESSION['role'] === 'hospital'; }
function isDonor() { return isset($_SESSION['role']) && $_SESSION['role'] === 'donor'; }
function isLoggedIn() { return isset($_SESSION['role']); }

function requireAdmin() {
    if (!isAdmin()) { header("Location: ../index.php?error=unauthorized"); exit; }
}
function requireHospital() {
    if (!isHospital()) { header("Location: ../index.php?error=unauthorized"); exit; }
}
function requireDonor() {
    if (!isDonor()) { header("Location: ../index.php?error=unauthorized"); exit; }
}
?>
