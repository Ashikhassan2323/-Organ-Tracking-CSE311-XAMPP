<?php
function renderSidebar($role, $active = '') {
    $links = [];
    $brand = '';
    $foot = '';

    if ($role === 'admin') {
        $brand = ['🫀', 'OrganMS', 'Admin Panel'];
        $links = [
            ['dashboard.php', '📊', 'Dashboard'],
            ['hospitals.php', '🏥', 'Hospitals'],
            ['donors.php', '💉', 'Donors'],
            ['recipients.php', '🧑‍⚕️', 'Recipients'],
            ['organs.php', '🫁', 'Organ Stock'],
            ['matches.php', '🔗', 'Matches'],
            ['transplants.php', '✅', 'Transplants'],
            ['payments.php', '💳', 'Payments'],
        ];
        $foot = 'Admin: ' . htmlspecialchars($_SESSION['name'] ?? 'Admin');
    } elseif ($role === 'hospital') {
        $brand = ['🏥', 'OrganMS', 'Hospital Portal'];
        $links = [
            ['dashboard.php', '📊', 'Dashboard'],
            ['organ_stock.php', '🫁', 'Organ Stock'],
            ['recipients.php', '🧑‍⚕️', 'My Recipients'],
            ['matches.php', '🔗', 'Matches'],
            ['donors.php', '💉', 'Contact Donors'],
            ['pay_donor.php', '💸', 'Pay Donor'],
            ['subscription.php', '💳', 'Subscription'],
        ];
        $foot = htmlspecialchars($_SESSION['name'] ?? 'Hospital');
    } elseif ($role === 'donor') {
        $brand = ['💉', 'OrganMS', 'Donor Portal'];
        $links = [
            ['dashboard.php', '📊', 'My Profile'],
            ['organs.php', '🫁', 'My Organs'],
            ['payments.php', '💳', 'My Payments'],
        ];
        $foot = htmlspecialchars($_SESSION['name'] ?? 'Donor');
    }

    echo '<div class="sidebar">';
    echo '<div class="brand"><span class="logo">' . $brand[0] . '</span><div><h2>' . $brand[1] . '</h2><small>' . $brand[2] . '</small></div></div>';
    echo '<nav>';
    foreach ($links as $l) {
        $cls = ($active === $l[0] || basename($_SERVER['PHP_SELF']) === $l[0]) ? ' active' : '';
        echo '<a href="' . $l[0] . '" class="' . $cls . '"><span class="icon">' . $l[1] . '</span>' . $l[2] . '</a>';
    }
    echo '</nav>';
    echo '<div class="sidebar-footer">' . $foot . '<br><a href="../logout.php" style="color:#ef4444;font-size:12px;">🚪 Logout</a></div>';
    echo '</div>';
}
?>
