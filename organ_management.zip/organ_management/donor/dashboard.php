<?php
session_start();
require_once '../includes/auth.php';
require_once '../includes/config.php';
require_once '../includes/sidebar.php';
requireDonor();
$did = $_SESSION['donor_id'];

$donor = $conn->query("SELECT d.*, h.hospital_name as paying_hospital FROM donor d LEFT JOIN hospital h ON d.paid_by_hospital_id=h.hospital_id WHERE d.donor_id=$did")->fetch_assoc();
$verified_total = $conn->query("SELECT COALESCE(SUM(amount),0) s FROM payments WHERE donor_id=$did AND payer_type='hospital_to_donor' AND payment_status='verified'")->fetch_assoc()['s'];
$organs = $conn->query("SELECT * FROM organ WHERE donor_id=$did");
$organ_count = $organs->num_rows;
$payments = $conn->query("SELECT p.*, h.hospital_name FROM payments p JOIN hospital h ON p.hospital_id=h.hospital_id WHERE p.donor_id=$did ORDER BY p.payment_date DESC");

$msg='';
if($_SERVER['REQUEST_METHOD']==='POST' && $_POST['action']==='update_profile'){
    $addr=sanitize($conn,$_POST['address']);
    $phone=sanitize($conn,$_POST['phone']);
    $conn->query("UPDATE donor SET address='$addr', phone='$phone' WHERE donor_id=$did");
    $msg="Profile updated.";
    header("Location: dashboard.php?msg=updated"); exit;
}
?>
<!DOCTYPE html><html lang="en">
<head><meta charset="UTF-8"><title>My Profile — Donor</title><link rel="stylesheet" href="../css/style.css"></head>
<body><div class="wrapper"><?php renderSidebar('donor','dashboard.php');?>
<div class="main-content">
<div class="topbar">
<h1>💉 My Donor Profile</h1>
<div class="topbar-right"><span class="user-badge">💉 <?=htmlspecialchars($_SESSION['name'])?></span></div>
</div>
<div class="page-body">
<?php if(isset($_GET['msg'])&&$_GET['msg']==='updated'):?><div class="alert alert-success">Profile updated successfully.</div><?php endif;?>

<div style="display:grid;grid-template-columns:1fr 1fr;gap:20px">
<div class="card">
<div class="card-title">👤 Profile Information</div>
<table style="font-size:14px">
<tr><td style="color:#64748b;padding:6px 12px 6px 0;width:140px">Full Name</td><td><b><?=htmlspecialchars($donor['full_name'])?></b></td></tr>
<tr><td style="color:#64748b;padding:6px 12px 6px 0">Blood Group</td><td><span class="badge badge-info"><?=$donor['blood_group']?></span></td></tr>
<tr><td style="color:#64748b;padding:6px 12px 6px 0">Gender</td><td><?=$donor['gender']?></td></tr>
<tr><td style="color:#64748b;padding:6px 12px 6px 0">Date of Birth</td><td><?=htmlspecialchars($donor['date_of_birth'])?></td></tr>
<tr><td style="color:#64748b;padding:6px 12px 6px 0">Phone</td><td><?=htmlspecialchars($donor['phone'])?></td></tr>
<tr><td style="color:#64748b;padding:6px 12px 6px 0">Address</td><td><?=htmlspecialchars($donor['address'])?></td></tr>
<tr><td style="color:#64748b;padding:6px 12px 6px 0">Medical Status</td><td><?=htmlspecialchars($donor['medical_status'])?></td></tr>
<tr><td style="color:#64748b;padding:6px 12px 6px 0">Eligibility</td>
<td><?php $ec=['eligible'=>'badge-success','ineligible'=>'badge-danger','pending'=>'badge-warning'];?>
<span class="badge <?=$ec[$donor['eligibility_status']]?>"><?=ucfirst($donor['eligibility_status'])?></span></td></tr>
<tr><td style="color:#64748b;padding:6px 12px 6px 0">Registered</td><td><?=date('M d, Y',strtotime($donor['registration_date']))?></td></tr>
</table>
</div>

<div>
<div class="stats-grid" style="grid-template-columns:1fr 1fr;margin-bottom:20px">
<div class="stat-card"><div class="stat-icon">🫁</div><div class="stat-value"><?=$organ_count?></div><div class="stat-label">Organs Registered</div></div>
<div class="stat-card"><div class="stat-icon">💰</div>
<div class="stat-value" style="font-size:18px">৳<?=number_format($verified_total,0)?></div>
<div class="stat-label">Received from Hospitals</div></div>
</div>

<?php if($donor['eligibility_status']==='pending'):?>
<div class="alert alert-warning">⏳ Your eligibility is pending review. A hospital will contact you for screening.</div>
<?php elseif($donor['eligibility_status']==='eligible'):?>
<div class="alert alert-success">✅ You are marked as eligible. Hospitals can see your profile and contact you.</div>
<?php else:?>
<div class="alert alert-danger">❌ Currently marked ineligible. Contact admin for more information.</div>
<?php endif;?>

<div class="card">
<div class="card-title">✏️ Update Profile</div>
<form method="POST">
<input type="hidden" name="action" value="update_profile">
<div class="form-group"><label>Phone</label><input name="phone" class="form-control" value="<?=htmlspecialchars($donor['phone'])?>"></div>
<div class="form-group"><label>Address</label><textarea name="address" class="form-control" rows="2"><?=htmlspecialchars($donor['address'])?></textarea></div>
<button type="submit" class="btn btn-primary">Save Changes</button>
</form>
</div>
</div>
</div>

<div class="card">
<div class="card-title">💳 Payments Received from Hospitals</div>
<?php $payments->data_seek(0); $has=$payments->num_rows>0; ?>
<?php if(!$has):?>
<p style="color:#64748b;font-size:13px">No payments received yet. Once a hospital compensates you, it will appear here.</p>
<?php else:?>
<div class="table-wrap"><table>
<thead><tr><th>Hospital</th><th>Amount</th><th>bKash TXN</th><th>Purpose</th><th>Date</th><th>Status</th></tr></thead>
<tbody>
<?php while($p=$payments->fetch_assoc()):?>
<tr>
<td><?=htmlspecialchars($p['hospital_name'])?></td>
<td><b>৳<?=number_format($p['amount'],2)?></b></td>
<td><code><?=htmlspecialchars($p['bkash_transaction_id'])?></code></td>
<td><?=htmlspecialchars($p['purpose'])?></td>
<td><?=date('M d, Y',strtotime($p['payment_date']))?></td>
<td><?php $sc=['pending'=>'badge-warning','verified'=>'badge-success','rejected'=>'badge-danger'];?>
<span class="badge <?=$sc[$p['payment_status']]?>"><?=ucfirst($p['payment_status'])?></span></td>
</tr>
<?php endwhile;?>
</tbody></table></div>
<?php endif;?>
</div>
</div>
</div>
</div>
</body></html>
