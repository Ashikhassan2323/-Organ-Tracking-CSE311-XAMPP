<?php
session_start();
require_once '../includes/auth.php';
require_once '../includes/config.php';
require_once '../includes/sidebar.php';
requireDonor();

$did = $_SESSION['donor_id'];
$msg = '';
$err = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $otype = sanitize($conn, $_POST['organ_type']);
    $hid = isset($_POST['hospital_id']) && $_POST['hospital_id'] !== '' ? (int)$_POST['hospital_id'] : 'NULL';

    if ($otype === '') {
        $err = "Please select an organ type.";
    } else {
        $sql = "INSERT INTO organ 
                (donor_id, hospital_id, organ_type, approval_status, reviewed_by_hospital_id, reviewed_at, rejection_reason, availability_status)
                VALUES 
                ($did, $hid, '$otype', 'pending', NULL, NULL, NULL, 'available')";

        if ($conn->query($sql)) {
            $msg = "Organ registered successfully. It is now pending hospital review.";
        } else {
            $err = "Failed to register organ: " . $conn->error;
        }
    }
}

$organs = $conn->query("
    SELECT 
        o.*,
        h.hospital_name,
        rh.hospital_name AS reviewed_hospital_name
    FROM organ o
    LEFT JOIN hospital h ON o.hospital_id = h.hospital_id
    LEFT JOIN hospital rh ON o.reviewed_by_hospital_id = rh.hospital_id
    WHERE o.donor_id = $did
    ORDER BY o.date_added DESC
");

$hospitals = $conn->query("
    SELECT hospital_id, hospital_name
    FROM hospital
    WHERE subscription_status = 'active'
    ORDER BY hospital_name
");

$organ_types = ['Kidney', 'Liver', 'Heart', 'Lung', 'Cornea', 'Pancreas', 'Intestine', 'Bone Marrow'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>My Organs — Donor</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
<div class="wrapper">
    <?php renderSidebar('donor', 'organs.php'); ?>

    <div class="main-content">
        <div class="topbar">
            <h1>🫁 My Registered Organs</h1>
        </div>

        <div class="page-body">
            <?php if ($msg): ?>
                <div class="alert alert-success"><?= htmlspecialchars($msg) ?></div>
            <?php endif; ?>

            <?php if ($err): ?>
                <div class="alert alert-danger"><?= htmlspecialchars($err) ?></div>
            <?php endif; ?>

            <div class="card" style="max-width:520px">
                <div class="card-title">+ Register an Organ for Donation</div>
                <form method="POST">
                    <div class="form-group">
                        <label>Organ Type</label>
                        <select name="organ_type" class="form-control" required>
                            <option value="">Select Organ Type</option>
                            <?php foreach ($organ_types as $t): ?>
                                <option value="<?= htmlspecialchars($t) ?>"><?= htmlspecialchars($t) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <label>Send to Hospital for Review (optional)</label>
                        <select name="hospital_id" class="form-control">
                            <option value="">No specific hospital</option>
                            <?php while ($h = $hospitals->fetch_assoc()): ?>
                                <option value="<?= $h['hospital_id'] ?>"><?= htmlspecialchars($h['hospital_name']) ?></option>
                            <?php endwhile; ?>
                        </select>
                    </div>

                    <div class="alert alert-info" style="font-size:13px">
                        After registration, the organ will remain <b>Pending</b> until a hospital accepts or rejects it.
                    </div>

                    <button type="submit" class="btn btn-primary">Register Organ</button>
                </form>
            </div>

            <div class="card">
                <div class="card-title">📋 My Organs</div>

                <?php if ($organs->num_rows === 0): ?>
                    <p style="color:#64748b;font-size:13px">You have not registered any organs yet.</p>
                <?php else: ?>
                    <div class="table-wrap">
                        <table>
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Organ Type</th>
                                    <th>Requested Hospital</th>
                                    <th>Approval Status</th>
                                    <th>Reviewed By</th>
                                    <th>Availability</th>
                                    <th>Rejected Reason</th>
                                    <th>Date Added</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php while ($o = $organs->fetch_assoc()): ?>
                                    <tr>
                                        <td><?= $o['organ_id'] ?></td>
                                        <td><b><?= htmlspecialchars($o['organ_type']) ?></b></td>
                                        <td><?= htmlspecialchars($o['hospital_name'] ?? 'Unassigned') ?></td>

                                        <td>
                                            <?php
                                            $approvalClass = [
                                                'pending' => 'badge-warning',
                                                'accepted' => 'badge-success',
                                                'rejected' => 'badge-danger'
                                            ];
                                            ?>
                                            <span class="badge <?= $approvalClass[$o['approval_status']] ?>">
                                                <?= ucfirst($o['approval_status']) ?>
                                            </span>
                                        </td>

                                        <td><?= htmlspecialchars($o['reviewed_hospital_name'] ?? '—') ?></td>

                                        <td>
                                            <?php
                                            $statusClass = [
                                                'available' => 'badge-success',
                                                'matched' => 'badge-warning',
                                                'used' => 'badge-secondary'
                                            ];
                                            ?>
                                            <span class="badge <?= $statusClass[$o['availability_status']] ?>">
                                                <?= ucfirst($o['availability_status']) ?>
                                            </span>
                                        </td>

                                        <td><?= htmlspecialchars($o['rejection_reason'] ?? '—') ?></td>
                                        <td><?= date('M d, Y', strtotime($o['date_added'])) ?></td>
                                    </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
</body>
</html>