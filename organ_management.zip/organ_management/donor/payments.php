<?php
session_start();
require_once '../includes/auth.php';
require_once '../includes/config.php';
require_once '../includes/sidebar.php';
requireDonor();
$did = $_SESSION['donor_id'];
$payments=$conn->query("SELECT p.*,h.hospital_name FROM payments p JOIN hospital h ON p.hospital_id=h.hospital_id WHERE p.donor_id=$did ORDER BY p.payment_date DESC");
$total=$conn->query("SELECT SUM(amount) s FROM payments WHERE donor_id=$did AND payment_status='verified'")->fetch_assoc()['s']??0;
?>
<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8"><title>My Payments — Donor</title><link rel="stylesheet" href="../css/style.css"></head>
<body><div class="wrapper"><?php renderSidebar('donor','payments.php');?>
<div class="main-content">
<div class="topbar"><h1>💳 My Payments</h1></div>
<div class="page-body">
<div class="stats-grid" style="max-width:400px">
<div class="stat-card"><div class="stat-icon">💰</div><div class="stat-value">৳<?=number_format($total,0)?></div><div class="stat-label">Total Verified Received</div></div>
</div>
<div class="card">
<div class="table-wrap"><table>
<thead><tr><th>Hospital</th><th>Amount</th><th>bKash TXN</th><th>Purpose</th><th>Date</th><th>Status</th></tr></thead>
<tbody>
<?php if($payments->num_rows===0):?>
<tr><td colspan="6" style="text-align:center;color:#64748b;padding:30px">No payments received yet.</td></tr>
<?php else: while($p=$payments->fetch_assoc()):?>
<tr>
<td><?=htmlspecialchars($p['hospital_name'])?></td>
<td><b>৳<?=number_format($p['amount'],2)?></b></td>
<td><code><?=htmlspecialchars($p['bkash_transaction_id'])?></code></td>
<td><?=htmlspecialchars($p['purpose'])?></td>
<td><?=date('M d, Y',strtotime($p['payment_date']))?></td>
<td><?php $sc=['pending'=>'badge-warning','verified'=>'badge-success','rejected'=>'badge-danger'];?>
<span class="badge <?=$sc[$p['payment_status']]?>"><?=ucfirst($p['payment_status'])?></span></td>
</tr>
<?php endwhile; endif;?>
</tbody></table></div></div>
</div></div></div>
</body></html>
