<?php
session_start();
require_once '../includes/config.php';
$msg='';$err='';

if($_SERVER['REQUEST_METHOD']==='POST'){
    $name=sanitize($conn,$_POST['full_name']);
    $gender=sanitize($conn,$_POST['gender']);
    $dob=sanitize($conn,$_POST['date_of_birth']);
    $bg=sanitize($conn,$_POST['blood_group']);
    $phone=sanitize($conn,$_POST['phone']);
    $addr=sanitize($conn,$_POST['address']);
    $pass=hashPassword($_POST['password']);

    $check=$conn->query("SELECT donor_id FROM donor WHERE phone='$phone' LIMIT 1");
    if($check->num_rows>0){ $err="Phone number already registered."; }
    else {
        $conn->query("INSERT INTO donor (full_name,gender,date_of_birth,blood_group,phone,address,password_hash,eligibility_status,medical_status)
            VALUES ('$name','$gender','$dob','$bg','$phone','$addr','$pass','pending','Awaiting Review')");
        $did=$conn->insert_id;
        $msg="Registration successful! Your Donor ID: <b>$did</b>, Login with phone: <b>$phone</b> or donor ID: <b>$did</b>.<br>A hospital will contact you for eligibility check.";
    }
}
?>
<!DOCTYPE html><html lang="en">
<head><meta charset="UTF-8"><title>Donor Registration — OrganMS</title><link rel="stylesheet" href="../css/style.css"></head>
<body>
<div class="login-page">
<div class="login-box" style="max-width:520px">
    <div class="login-logo">
        <div class="emoji">💉</div>
        <h1>Register as Donor</h1>
        <p>Free registration · Save a life</p>
    </div>

    <?php if($msg):?><div class="alert alert-success"><?=$msg?><br><br><a href="../index.php" class="btn btn-primary">Login Now</a></div>
    <?php elseif($err):?><div class="alert alert-danger"><?=$err?></div><?php endif;?>

    <?php if(!$msg):?>
    <div class="alert alert-info" style="font-size:12px">
        ✅ Donor registration is <b>completely free</b>. Hospitals will contact you for eligibility screening. You may also receive compensation from hospitals.
    </div>
    <form method="POST">
    <div class="form-row">
    <div class="form-group"><label>Full Name</label><input name="full_name" class="form-control" required></div>
    <div class="form-group"><label>Gender</label><select name="gender" class="form-control"><option>Male</option><option>Female</option><option>Other</option></select></div>
    </div>
    <div class="form-row">
    <div class="form-group"><label>Date of Birth</label><input type="date" name="date_of_birth" class="form-control" required></div>
    <div class="form-group"><label>Blood Group</label><select name="blood_group" class="form-control">
    <?php foreach(['A+','A-','B+','B-','O+','O-','AB+','AB-'] as $bg) echo "<option>$bg</option>";?></select></div>
    </div>
    <div class="form-group"><label>Phone Number (used as Login ID)</label><input name="phone" class="form-control" required placeholder="01XXXXXXXXX"></div>
    <div class="form-group"><label>Address</label><textarea name="address" class="form-control" rows="2" placeholder="City, District"></textarea></div>
    <div class="form-group"><label>Password</label><input type="password" name="password" class="form-control" required minlength="6" placeholder="Min 6 characters"></div>
    <button type="submit" class="btn btn-primary" style="width:100%">Register Free →</button>
    <p style="text-align:center;margin-top:14px;font-size:13px;color:#64748b">Already registered? <a href="../index.php" style="color:#2563eb">Login</a></p>
    </form>
    <?php endif;?>
</div>
</div>
</body></html>
