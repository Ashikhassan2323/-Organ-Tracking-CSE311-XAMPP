<?php
session_start();
require_once '../includes/auth.php';
require_once '../includes/config.php';
require_once '../includes/sidebar.php';
requireAdmin();
$msg='';$err='';
if($_SERVER['REQUEST_METHOD']==='POST'){
    $action=$_POST['action']??'';
    if($action==='add'){
        $name=sanitize($conn,$_POST['full_name']);$gender=sanitize($conn,$_POST['gender']);
        $dob=sanitize($conn,$_POST['date_of_birth']);$bg=sanitize($conn,$_POST['blood_group']);
        $phone=sanitize($conn,$_POST['phone']);$addr=sanitize($conn,$_POST['address']);
        $organ=sanitize($conn,$_POST['needed_organ_type']);$urg=sanitize($conn,$_POST['urgency_level']);
        $hid=$_POST['hospital_id']?(int)$_POST['hospital_id']:'NULL';
        $conn->query("INSERT INTO recipient (full_name,gender,date_of_birth,blood_group,phone,address,needed_organ_type,urgency_level,hospital_id)
            VALUES ('$name','$gender','$dob','$bg','$phone','$addr','$organ','$urg',$hid)");
        $msg="Recipient added.";
    } elseif($action==='update_status'){
        $id=(int)$_POST['recipient_id'];$st=sanitize($conn,$_POST['status']);
        $conn->query("UPDATE recipient SET status='$st' WHERE recipient_id=$id");
        $msg="Status updated.";
    } elseif($action==='delete'){
        $id=(int)$_POST['recipient_id'];
        if($conn->query("DELETE FROM recipient WHERE recipient_id=$id")) $msg="Recipient deleted.";
        else $err="Cannot delete: linked records exist.";
    }
}
$recipients=$conn->query("SELECT r.*,h.hospital_name FROM recipient r LEFT JOIN hospital h ON r.hospital_id=h.hospital_id ORDER BY FIELD(r.urgency_level,'Critical','High','Medium','Low'), r.registration_date");
$hospitals=$conn->query("SELECT hospital_id,hospital_name FROM hospital WHERE subscription_status='active'");
$h_arr=[];while($hh=$hospitals->fetch_assoc()) $h_arr[]=$hh;
$organ_types=['Kidney','Liver','Heart','Lung','Cornea','Pancreas','Intestine','Bone Marrow'];
?>
<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8"><title>Recipients — Admin</title><link rel="stylesheet" href="../css/style.css"></head>
<body><div class="wrapper"><?php renderSidebar('admin'); ?>
<div class="main-content">
<div class="topbar"><h1>🧑‍⚕️ Recipients</h1><div class="topbar-right"><button class="btn btn-primary btn-sm" onclick="document.getElementById('addModal').style.display='flex'">+ Add Recipient</button></div></div>
<div class="page-body">
<?php if($msg):?><div class="alert alert-success"><?=$msg?></div><?php endif;?>
<?php if($err):?><div class="alert alert-danger"><?=$err?></div><?php endif;?>
<div class="card"><div class="table-wrap"><table>
<thead><tr><th>#</th><th>Name</th><th>Blood</th><th>Needed Organ</th><th>Urgency</th><th>Hospital</th><th>Status</th><th>Actions</th></tr></thead>
<tbody>
<?php while($r=$recipients->fetch_assoc()):?>
<tr>
<td><?=$r['recipient_id']?></td>
<td><b><?=htmlspecialchars($r['full_name'])?></b><br><small style="color:#64748b"><?=$r['gender']?></small></td>
<td><span class="badge badge-info"><?=$r['blood_group']?></span></td>
<td><?=htmlspecialchars($r['needed_organ_type'])?></td>
<td><span class="urgency-<?=$r['urgency_level']?>"><?=$r['urgency_level']?></span></td>
<td><?=htmlspecialchars($r['hospital_name']??'—')?></td>
<td>
<?php $sc=['waiting'=>'badge-warning','matched'=>'badge-info','transplanted'=>'badge-success'];?>
<span class="badge <?=$sc[$r['status']]?>"><?=ucfirst($r['status'])?></span>
</td>
<td>
<form method="POST" style="display:inline">
<input type="hidden" name="action" value="update_status"><input type="hidden" name="recipient_id" value="<?=$r['recipient_id']?>">
<select name="status" class="form-control" style="display:inline;width:110px;padding:4px 6px;font-size:12px">
<?php foreach(['waiting','matched','transplanted'] as $s): ?><option value="<?=$s?>" <?=$r['status']===$s?'selected':''?>><?=ucfirst($s)?></option><?php endforeach;?>
</select>
<button type="submit" class="btn btn-sm btn-success">✓</button>
</form>
<form method="POST" style="display:inline"><input type="hidden" name="action" value="delete"><input type="hidden" name="recipient_id" value="<?=$r['recipient_id']?>">
<button type="submit" class="btn btn-sm btn-danger" onclick="return confirm('Delete?')">🗑</button></form>
</td>
</tr>
<?php endwhile;?>
</tbody></table></div></div>
</div></div></div>
<div id="addModal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.5);z-index:999;align-items:center;justify-content:center">
<div style="background:#fff;border-radius:16px;padding:32px;width:560px;max-height:90vh;overflow-y:auto;position:relative">
<button onclick="document.getElementById('addModal').style.display='none'" style="position:absolute;top:16px;right:16px;background:none;border:none;font-size:20px;cursor:pointer">✕</button>
<h3 style="margin-bottom:20px">Add Recipient</h3>
<form method="POST"><input type="hidden" name="action" value="add">
<div class="form-row">
<div class="form-group"><label>Full Name</label><input name="full_name" class="form-control" required></div>
<div class="form-group"><label>Gender</label><select name="gender" class="form-control"><option>Male</option><option>Female</option><option>Other</option></select></div>
</div>
<div class="form-row">
<div class="form-group"><label>DOB</label><input type="date" name="date_of_birth" class="form-control"></div>
<div class="form-group"><label>Blood Group</label><select name="blood_group" class="form-control"><?php foreach(['A+','A-','B+','B-','O+','O-','AB+','AB-'] as $bg) echo "<option>$bg</option>";?></select></div>
</div>
<div class="form-row">
<div class="form-group"><label>Phone</label><input name="phone" class="form-control"></div>
<div class="form-group"><label>Needed Organ</label><select name="needed_organ_type" class="form-control"><?php foreach($organ_types as $t) echo "<option>$t</option>";?></select></div>
</div>
<div class="form-row">
<div class="form-group"><label>Urgency</label><select name="urgency_level" class="form-control"><option>Low</option><option>Medium</option><option selected>High</option><option>Critical</option></select></div>
<div class="form-group"><label>Hospital</label><select name="hospital_id" class="form-control"><option value="">None</option><?php foreach($h_arr as $hh) echo "<option value='{$hh['hospital_id']}'>" . htmlspecialchars($hh['hospital_name']) . "</option>";?></select></div>
</div>
<div class="form-group"><label>Address</label><textarea name="address" class="form-control" rows="2"></textarea></div>
<button type="submit" class="btn btn-primary" style="width:100%">Add Recipient</button>
</form>
</div></div>
</body></html>
