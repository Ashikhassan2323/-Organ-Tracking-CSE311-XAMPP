<?php
session_start();
require_once '../includes/auth.php';
require_once '../includes/config.php';
require_once '../includes/sidebar.php';
requireAdmin();

$msg = ''; $err = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    if ($action === 'add') {
        $did = (int)$_POST['donor_id'];
        $hid = $_POST['hospital_id'] ? (int)$_POST['hospital_id'] : 'NULL';
        $otype = sanitize($conn, $_POST['organ_type']);
        $status = sanitize($conn, $_POST['availability_status']);
        $conn->query("INSERT INTO organ (donor_id,hospital_id,organ_type,availability_status) VALUES ($did,$hid,'$otype','$status')");
        $msg = "Organ added.";
    } elseif ($action === 'update') {
        $oid = (int)$_POST['organ_id'];
        $status = sanitize($conn, $_POST['availability_status']);
        $hid = $_POST['hospital_id'] ? (int)$_POST['hospital_id'] : 'NULL';
        $conn->query("UPDATE organ SET availability_status='$status', hospital_id=$hid WHERE organ_id=$oid");
        $msg = "Organ updated.";
    } elseif ($action === 'delete') {
        $oid = (int)$_POST['organ_id'];
        if ($conn->query("DELETE FROM organ WHERE organ_id=$oid")) $msg = "Organ deleted.";
        else $err = "Cannot delete: organ is linked to matches/transplants.";
    }
}

$organs = $conn->query("SELECT o.*, d.full_name as donor_name, d.blood_group, h.hospital_name
    FROM organ o JOIN donor d ON o.donor_id=d.donor_id LEFT JOIN hospital h ON o.hospital_id=h.hospital_id
    ORDER BY o.date_added DESC");
$donors = $conn->query("SELECT donor_id, full_name, blood_group FROM donor WHERE eligibility_status='eligible'");
$hospitals = $conn->query("SELECT hospital_id, hospital_name FROM hospital WHERE subscription_status='active'");
$donors_arr = []; while($r=$donors->fetch_assoc()) $donors_arr[]=$r;
$hospitals_arr = []; while($r=$hospitals->fetch_assoc()) $hospitals_arr[]=$r;
$organ_types = ['Kidney','Liver','Heart','Lung','Cornea','Pancreas','Intestine','Bone Marrow'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Organs — Admin</title>
<link rel="stylesheet" href="../css/style.css">
</head>
<body>
<div class="wrapper">
<?php renderSidebar('admin'); ?>
<div class="main-content">
<div class="topbar">
    <h1>🫁 Organ Stock Management</h1>
    <div class="topbar-right">
        <button class="btn btn-primary btn-sm" onclick="document.getElementById('addModal').style.display='flex'">+ Add Organ</button>
    </div>
</div>
<div class="page-body">
<?php if ($msg): ?><div class="alert alert-success"><?= $msg ?></div><?php endif; ?>
<?php if ($err): ?><div class="alert alert-danger"><?= $err ?></div><?php endif; ?>

<div class="card">
<div class="table-wrap">
<table>
<thead>
<tr><th>#</th><th>Organ Type</th><th>Donor</th><th>Blood Group</th><th>Hospital</th><th>Status</th><th>Date Added</th><th>Actions</th></tr>
</thead>
<tbody>
<?php while ($o = $organs->fetch_assoc()): ?>
<tr>
    <td><?= $o['organ_id'] ?></td>
    <td><b><?= htmlspecialchars($o['organ_type']) ?></b></td>
    <td><?= htmlspecialchars($o['donor_name']) ?></td>
    <td><span class="badge badge-info"><?= htmlspecialchars($o['blood_group']) ?></span></td>
    <td><?= htmlspecialchars($o['hospital_name'] ?? '—') ?></td>
    <td>
        <?php $sc=['available'=>'badge-success','matched'=>'badge-warning','used'=>'badge-secondary']; ?>
        <span class="badge <?= $sc[$o['availability_status']] ?>"><?= ucfirst($o['availability_status']) ?></span>
    </td>
    <td><?= date('M d, Y', strtotime($o['date_added'])) ?></td>
    <td>
        <form method="POST" style="display:inline">
            <input type="hidden" name="action" value="update">
            <input type="hidden" name="organ_id" value="<?= $o['organ_id'] ?>">
            <select name="availability_status" class="form-control" style="display:inline;width:100px;padding:4px 6px;font-size:12px">
                <?php foreach(['available','matched','used'] as $s): ?>
                <option value="<?= $s ?>" <?= $o['availability_status']===$s?'selected':'' ?>><?= ucfirst($s) ?></option>
                <?php endforeach; ?>
            </select>
            <select name="hospital_id" class="form-control" style="display:inline;width:130px;padding:4px 6px;font-size:12px">
                <option value="">No Hospital</option>
                <?php foreach($hospitals_arr as $hh): ?>
                <option value="<?= $hh['hospital_id'] ?>" <?= $o['hospital_id']==$hh['hospital_id']?'selected':'' ?>><?= htmlspecialchars($hh['hospital_name']) ?></option>
                <?php endforeach; ?>
            </select>
            <button type="submit" class="btn btn-sm btn-success">✓</button>
        </form>
        <form method="POST" style="display:inline">
            <input type="hidden" name="action" value="delete">
            <input type="hidden" name="organ_id" value="<?= $o['organ_id'] ?>">
            <button type="submit" class="btn btn-sm btn-danger" onclick="return confirm('Delete organ record?')">🗑</button>
        </form>
    </td>
</tr>
<?php endwhile; ?>
</tbody>
</table>
</div>
</div>
</div>
</div>
</div>

<!-- Add Organ Modal -->
<div id="addModal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.5);z-index:999;align-items:center;justify-content:center">
<div style="background:#fff;border-radius:16px;padding:32px;width:480px;position:relative">
<button onclick="document.getElementById('addModal').style.display='none'" style="position:absolute;top:16px;right:16px;background:none;border:none;font-size:20px;cursor:pointer">✕</button>
<h3 style="margin-bottom:20px">Add New Organ</h3>
<form method="POST">
<input type="hidden" name="action" value="add">
<div class="form-group"><label>Donor</label>
    <select name="donor_id" class="form-control" required>
        <option value="">Select Eligible Donor</option>
        <?php foreach($donors_arr as $d): ?>
        <option value="<?= $d['donor_id'] ?>"><?= htmlspecialchars($d['full_name']) ?> (<?= $d['blood_group'] ?>)</option>
        <?php endforeach; ?>
    </select>
</div>
<div class="form-group"><label>Organ Type</label>
    <select name="organ_type" class="form-control" required>
        <?php foreach($organ_types as $t) echo "<option>$t</option>"; ?>
    </select>
</div>
<div class="form-group"><label>Hospital</label>
    <select name="hospital_id" class="form-control">
        <option value="">Unassigned</option>
        <?php foreach($hospitals_arr as $hh): ?>
        <option value="<?= $hh['hospital_id'] ?>"><?= htmlspecialchars($hh['hospital_name']) ?></option>
        <?php endforeach; ?>
    </select>
</div>
<div class="form-group"><label>Availability</label>
    <select name="availability_status" class="form-control">
        <option value="available">Available</option>
        <option value="matched">Matched</option>
    </select>
</div>
<button type="submit" class="btn btn-primary" style="width:100%">Add Organ</button>
</form>
</div>
</div>
</body>
</html>
