<?php
session_start();
require_once '../includes/auth.php';
require_once '../includes/config.php';
require_once '../includes/sidebar.php';
requireAdmin();

$msg = ''; $err = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'approve') {
        $id = (int)$_POST['hospital_id'];
        $txn = sanitize($conn, $_POST['bkash_txn'] ?? '');
        $conn->query("UPDATE hospital SET subscription_status='active', bkash_transaction_id='$txn', subscription_paid_at=NOW() WHERE hospital_id=$id");
        $pending = $conn->query("SELECT payment_id FROM payments WHERE hospital_id=$id AND payer_type='hospital' AND payment_status='pending' ORDER BY payment_id DESC LIMIT 1")->fetch_assoc();
        if ($pending) {
            $conn->query("UPDATE payments SET payment_status='verified', bkash_transaction_id='$txn', verified_by_admin={$_SESSION['admin_id']} WHERE payment_id={$pending['payment_id']}");
        } else {
            $conn->query("INSERT INTO payments (payer_type,hospital_id,amount,bkash_transaction_id,payment_status,purpose,verified_by_admin)
                VALUES ('hospital',$id,5000,'$txn','verified','Annual Subscription',{$_SESSION['admin_id']})");
        }
        $msg = "Hospital subscription activated.";

    } elseif ($action === 'revoke') {
        $id = (int)$_POST['hospital_id'];
        $conn->query("UPDATE hospital SET subscription_status='expired' WHERE hospital_id=$id");
        $msg = "Subscription revoked.";

    } elseif ($action === 'delete') {
        $id = (int)$_POST['hospital_id'];
        if ($conn->query("DELETE FROM hospital WHERE hospital_id=$id")) $msg = "Hospital deleted.";
        else $err = "Cannot delete: hospital has linked records.";
    }
}

$hospitals = $conn->query("SELECT h.*, 
    (SELECT COUNT(*) FROM organ WHERE hospital_id=h.hospital_id AND availability_status='available') as organ_count,
    (SELECT COUNT(*) FROM recipient WHERE hospital_id=h.hospital_id) as recipient_count
    FROM hospital h ORDER BY h.created_at DESC");
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Hospitals — Admin</title>
<link rel="stylesheet" href="../css/style.css">
</head>
<body>
<div class="wrapper">
<?php renderSidebar('admin'); ?>
<div class="main-content">
<div class="topbar">
    <h1>🏥 Manage Hospitals</h1>
</div>
<div class="page-body">
<?php if ($msg): ?><div class="alert alert-success"><?= $msg ?></div><?php endif; ?>
<?php if ($err): ?><div class="alert alert-danger"><?= $err ?></div><?php endif; ?>

<div class="card">
<div class="table-wrap">
<table>
<thead>
<tr><th>#</th><th>Hospital</th><th>City</th><th>Reg No</th><th>Subscription</th><th>Organs</th><th>Recipients</th><th>bKash TXN</th><th>Actions</th></tr>
</thead>
<tbody>
<?php while ($h = $hospitals->fetch_assoc()): ?>
<tr>
    <td><?= $h['hospital_id'] ?></td>
    <td><b><?= htmlspecialchars($h['hospital_name']) ?></b><br><small style="color:#64748b"><?= htmlspecialchars($h['phone']) ?></small></td>
    <td><?= htmlspecialchars($h['city']) ?></td>
    <td><code><?= htmlspecialchars($h['registration_no']) ?></code></td>
    <td>
        <?php $sc=['active'=>'badge-success','pending'=>'badge-warning','expired'=>'badge-danger']; ?>
        <span class="badge <?= $sc[$h['subscription_status']] ?>"><?= ucfirst($h['subscription_status']) ?></span>
    </td>
    <td><span class="badge badge-info"><?= $h['organ_count'] ?></span></td>
    <td><?= $h['recipient_count'] ?></td>
    <td><small><?= htmlspecialchars($h['bkash_transaction_id'] ?? '-') ?></small></td>
    <td>
        <?php if ($h['subscription_status'] !== 'active'): ?>
        <form method="POST" style="display:inline">
            <input type="hidden" name="action" value="approve">
            <input type="hidden" name="hospital_id" value="<?= $h['hospital_id'] ?>">
            <input type="text" name="bkash_txn" placeholder="bKash TXN ID" class="form-control" style="width:130px;display:inline;padding:4px 6px;font-size:12px" required>
            <button type="submit" class="btn btn-sm btn-success">Activate</button>
        </form>
        <?php else: ?>
        <form method="POST" style="display:inline">
            <input type="hidden" name="action" value="revoke">
            <input type="hidden" name="hospital_id" value="<?= $h['hospital_id'] ?>">
            <button type="submit" class="btn btn-sm btn-warning" onclick="return confirm('Revoke subscription?')">Revoke</button>
        </form>
        <?php endif; ?>
        <form method="POST" style="display:inline">
            <input type="hidden" name="action" value="delete">
            <input type="hidden" name="hospital_id" value="<?= $h['hospital_id'] ?>">
            <button type="submit" class="btn btn-sm btn-danger" onclick="return confirm('Delete hospital?')">🗑</button>
        </form>
    </td>
</tr>
<?php endwhile; ?>
</tbody>
</table>
</div>
</div>
</div>
</div>
</div>
</body>
</html>
