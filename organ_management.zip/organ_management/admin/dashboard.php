<?php
session_start();
require_once '../includes/auth.php';
require_once '../includes/config.php';
require_once '../includes/sidebar.php';
requireAdmin();

$stats = [
    'hospitals' => $conn->query("SELECT COUNT(*) c FROM hospital")->fetch_assoc()['c'],
    'active_hospitals' => $conn->query("SELECT COUNT(*) c FROM hospital WHERE subscription_status='active'")->fetch_assoc()['c'],
    'donors' => $conn->query("SELECT COUNT(*) c FROM donor")->fetch_assoc()['c'],
    'eligible_donors' => $conn->query("SELECT COUNT(*) c FROM donor WHERE eligibility_status='eligible'")->fetch_assoc()['c'],
    'recipients' => $conn->query("SELECT COUNT(*) c FROM recipient")->fetch_assoc()['c'],
    'organs_available' => $conn->query("SELECT COUNT(*) c FROM organ WHERE availability_status='available'")->fetch_assoc()['c'],
    'transplants' => $conn->query("SELECT COUNT(*) c FROM transplant")->fetch_assoc()['c'],
    'pending_payments' => $conn->query("SELECT COUNT(*) c FROM payments WHERE payment_status='pending'")->fetch_assoc()['c'],
];

$recent_organs = $conn->query("
    SELECT o.*, d.full_name as donor_name, d.blood_group, h.hospital_name
    FROM organ o
    JOIN donor d ON o.donor_id = d.donor_id
    LEFT JOIN hospital h ON o.hospital_id = h.hospital_id
    ORDER BY o.date_added DESC LIMIT 8
");
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta http-equiv="refresh" content="30">
<title>Admin Dashboard — OrganMS</title>
<link rel="stylesheet" href="../css/style.css">
</head>
<body>
<div class="wrapper">
<?php renderSidebar('admin', 'dashboard.php'); ?>
<div class="main-content">
<div class="topbar">
    <h1>📊 Admin Dashboard</h1>
    <div class="topbar-right">
        <span><span class="live-dot"></span>Live</span>
        <span class="user-badge">🔐 <?= htmlspecialchars($_SESSION['name']) ?></span>
    </div>
</div>
<div class="page-body">

<div class="stats-grid">
    <div class="stat-card">
        <div class="stat-icon">🏥</div>
        <div class="stat-value"><?= $stats['hospitals'] ?></div>
        <div class="stat-label">Total Hospitals</div>
    </div>
    <div class="stat-card">
        <div class="stat-icon">✅</div>
        <div class="stat-value"><?= $stats['active_hospitals'] ?></div>
        <div class="stat-label">Active Subscriptions</div>
    </div>
    <div class="stat-card">
        <div class="stat-icon">💉</div>
        <div class="stat-value"><?= $stats['donors'] ?></div>
        <div class="stat-label">Registered Donors</div>
    </div>
    <div class="stat-card">
        <div class="stat-icon">💚</div>
        <div class="stat-value"><?= $stats['eligible_donors'] ?></div>
        <div class="stat-label">Eligible Donors</div>
    </div>
    <div class="stat-card">
        <div class="stat-icon">🧑‍⚕️</div>
        <div class="stat-value"><?= $stats['recipients'] ?></div>
        <div class="stat-label">Recipients Waiting</div>
    </div>
    <div class="stat-card">
        <div class="stat-icon">🫁</div>
        <div class="stat-value"><?= $stats['organs_available'] ?></div>
        <div class="stat-label">Organs Available</div>
    </div>
    <div class="stat-card">
        <div class="stat-icon">🔗</div>
        <div class="stat-value"><?= $stats['transplants'] ?></div>
        <div class="stat-label">Transplants Done</div>
    </div>
    <div class="stat-card">
        <div class="stat-icon">⏳</div>
        <div class="stat-value" style="color:<?= $stats['pending_payments'] > 0 ? '#d97706' : '#16a34a' ?>"><?= $stats['pending_payments'] ?></div>
        <div class="stat-label">Pending Payments</div>
    </div>
</div>

<div class="card">
    <div class="card-title">🫁 Live Organ Stock</div>
    <div class="table-wrap">
    <table>
        <thead>
            <tr><th>Organ</th><th>Donor</th><th>Blood Group</th><th>Hospital</th><th>Status</th><th>Added</th></tr>
        </thead>
        <tbody>
        <?php while ($r = $recent_organs->fetch_assoc()): ?>
        <tr>
            <td><b><?= htmlspecialchars($r['organ_type']) ?></b></td>
            <td><?= htmlspecialchars($r['donor_name']) ?></td>
            <td><span class="badge badge-info"><?= htmlspecialchars($r['blood_group']) ?></span></td>
            <td><?= htmlspecialchars($r['hospital_name'] ?? 'Unassigned') ?></td>
            <td>
                <?php
                $sc = ['available'=>'badge-success','matched'=>'badge-warning','used'=>'badge-secondary'];
                echo '<span class="badge ' . ($sc[$r['availability_status']] ?? 'badge-secondary') . '">' . ucfirst($r['availability_status']) . '</span>';
                ?>
            </td>
            <td><?= date('M d, Y', strtotime($r['date_added'])) ?></td>
        </tr>
        <?php endwhile; ?>
        </tbody>
    </table>
    </div>
</div>

<div style="display:grid;grid-template-columns:1fr 1fr;gap:20px;">
<div class="card">
    <div class="card-title">⚡ Quick Actions</div>
    <div style="display:flex;flex-wrap:wrap;gap:10px;">
        <a href="donors.php" class="btn btn-primary btn-sm">+ Add Donor</a>
        <a href="recipients.php" class="btn btn-success btn-sm">+ Add Recipient</a>
        <a href="organs.php" class="btn btn-warning btn-sm">+ Add Organ</a>
        <a href="matches.php" class="btn btn-outline btn-sm">🔗 Create Match</a>
        <a href="hospitals.php" class="btn btn-secondary btn-sm">🏥 Hospitals</a>
        <a href="payments.php" class="btn btn-secondary btn-sm">💳 Payments</a>
    </div>
</div>
<div class="card">
    <div class="card-title">📋 System Info</div>
    <p style="font-size:13px;color:#64748b;line-height:1.8;">
        <b>Auto-refresh:</b> Every 30 seconds<br>
        <b>Role:</b> System Administrator<br>
        <b>Access:</b> Full CRUD on all modules<br>
        <b>DB:</b> organ_management (MySQL)
    </p>
</div>
</div>

</div>
</div>
</div>
</body>
</html>
