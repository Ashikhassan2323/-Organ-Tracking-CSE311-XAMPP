<?php
session_start();
require_once '../includes/auth.php';
require_once '../includes/config.php';
require_once '../includes/sidebar.php';
requireAdmin();

$msg = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $pid = (int)$_POST['payment_id'];
    $p = $conn->query("SELECT * FROM payments WHERE payment_id=$pid LIMIT 1")->fetch_assoc();

    if ($p) {
        if ($action === 'verify') {
            $conn->query("UPDATE payments SET payment_status='verified', verified_by_admin={$_SESSION['admin_id']} WHERE payment_id=$pid");

            if ($p['payer_type'] === 'hospital' && $p['hospital_id']) {
                $txn = sanitize($conn, $p['bkash_transaction_id'] ?? '');
                $conn->query("UPDATE hospital SET subscription_status='active', subscription_paid_at=NOW(), bkash_transaction_id='$txn' WHERE hospital_id={$p['hospital_id']}");
            }

            if ($p['payer_type'] === 'hospital_to_donor' && $p['donor_id']) {
                $conn->query("UPDATE donor SET paid_by_hospital_id={$p['hospital_id']}, payment_status='paid' WHERE donor_id={$p['donor_id']}");
                $conn->query("UPDATE donor SET payment_amount=(SELECT COALESCE(SUM(amount),0) FROM payments WHERE donor_id={$p['donor_id']} AND payer_type='hospital_to_donor' AND payment_status='verified') WHERE donor_id={$p['donor_id']}");
            }
            $msg = "Payment verified.";
        } elseif ($action === 'reject') {
            $conn->query("UPDATE payments SET payment_status='rejected', verified_by_admin={$_SESSION['admin_id']} WHERE payment_id=$pid");

            if ($p['payer_type'] === 'hospital_to_donor' && $p['donor_id']) {
                $conn->query("UPDATE donor SET payment_amount=(SELECT COALESCE(SUM(amount),0) FROM payments WHERE donor_id={$p['donor_id']} AND payer_type='hospital_to_donor' AND payment_status='verified') WHERE donor_id={$p['donor_id']}");
                $conn->query("UPDATE donor SET payment_status=CASE WHEN payment_amount > 0 THEN 'paid' ELSE 'none' END WHERE donor_id={$p['donor_id']}");
            }
            $msg = "Payment rejected.";
        }
    }
}

$payments = $conn->query("SELECT p.*, h.hospital_name, d.full_name as donor_name
    FROM payments p
    LEFT JOIN hospital h ON p.hospital_id = h.hospital_id
    LEFT JOIN donor d ON p.donor_id = d.donor_id
    ORDER BY p.payment_date DESC");
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Payments — Admin</title>
<link rel="stylesheet" href="../css/style.css">
</head>
<body>
<div class="wrapper">
<?php renderSidebar('admin'); ?>
<div class="main-content">
<div class="topbar"><h1>💳 Payment Management</h1></div>
<div class="page-body">
<?php if ($msg): ?><div class="alert alert-success"><?= $msg ?></div><?php endif; ?>
<div class="card">
<div class="table-wrap">
<table>
<thead>
<tr><th>#</th><th>Type</th><th>From</th><th>To</th><th>Amount (BDT)</th><th>bKash TXN</th><th>Purpose</th><th>Date</th><th>Status</th><th>Actions</th></tr>
</thead>
<tbody>
<?php while ($p = $payments->fetch_assoc()): ?>
<tr>
    <td><?= $p['payment_id'] ?></td>
    <td><span class="badge badge-info"><?= $p['payer_type'] === 'hospital' ? '🏥 Hospital' : '💸 H→Donor' ?></span></td>
    <td><?= htmlspecialchars($p['hospital_name'] ?? '—') ?></td>
    <td><?= htmlspecialchars($p['donor_name'] ?? '—') ?></td>
    <td><b>৳<?= number_format($p['amount'], 2) ?></b></td>
    <td><code><?= htmlspecialchars($p['bkash_transaction_id'] ?? '—') ?></code></td>
    <td><?= htmlspecialchars($p['purpose'] ?? '—') ?></td>
    <td><?= date('M d, Y', strtotime($p['payment_date'])) ?></td>
    <td>
        <?php $sc=['pending'=>'badge-warning','verified'=>'badge-success','rejected'=>'badge-danger']; ?>
        <span class="badge <?= $sc[$p['payment_status']] ?>"><?= ucfirst($p['payment_status']) ?></span>
    </td>
    <td>
        <?php if ($p['payment_status'] === 'pending'): ?>
        <form method="POST" style="display:inline">
            <input type="hidden" name="payment_id" value="<?= $p['payment_id'] ?>">
            <input type="hidden" name="action" value="verify">
            <button type="submit" class="btn btn-sm btn-success">✓ Verify</button>
        </form>
        <form method="POST" style="display:inline">
            <input type="hidden" name="payment_id" value="<?= $p['payment_id'] ?>">
            <input type="hidden" name="action" value="reject">
            <button type="submit" class="btn btn-sm btn-danger">✕ Reject</button>
        </form>
        <?php else: ?>
        <span style="color:#64748b;font-size:12px">Done</span>
        <?php endif; ?>
    </td>
</tr>
<?php endwhile; ?>
</tbody>
</table>
</div>
</div>
</div>
</div>
</div>
</body>
</html>
