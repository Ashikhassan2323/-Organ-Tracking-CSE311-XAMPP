<?php header("Location: matches.php"); exit; ?>
