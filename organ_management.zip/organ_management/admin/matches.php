<?php
session_start();
require_once '../includes/auth.php';
require_once '../includes/config.php';
require_once '../includes/sidebar.php';
requireAdmin();

$msg = '';
$err = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'add_match') {
        $rid = (int)$_POST['recipient_id'];
        $oid = (int)$_POST['organ_id'];

        $checkRecipient = $conn->query("SELECT * FROM recipient WHERE recipient_id=$rid AND status='waiting' LIMIT 1");
        $checkOrgan = $conn->query("
            SELECT *
            FROM organ
            WHERE organ_id=$oid
              AND approval_status='accepted'
              AND availability_status='available'
            LIMIT 1
        ");

        if ($checkRecipient->num_rows === 0) {
            $err = "Recipient is not available for matching.";
        } elseif ($checkOrgan->num_rows === 0) {
            $err = "Organ is not accepted/available for matching.";
        } else {
            $conn->query("INSERT INTO match_record (recipient_id, organ_id) VALUES ($rid, $oid)");
            $conn->query("UPDATE organ SET availability_status='matched' WHERE organ_id=$oid");
            $conn->query("UPDATE recipient SET status='matched' WHERE recipient_id=$rid");
            $msg = "Match created successfully.";
        }

    } elseif ($action === 'confirm') {
        $mid = (int)$_POST['match_id'];
        $conn->query("UPDATE match_record SET match_status='confirmed' WHERE match_id=$mid");
        $msg = "Match confirmed.";

    } elseif ($action === 'reject_match') {
        $mid = (int)$_POST['match_id'];

        $match = $conn->query("SELECT * FROM match_record WHERE match_id=$mid LIMIT 1")->fetch_assoc();
        if ($match) {
            $conn->query("UPDATE match_record SET match_status='rejected' WHERE match_id=$mid");
            $conn->query("UPDATE organ SET availability_status='available' WHERE organ_id={$match['organ_id']}");
            $conn->query("UPDATE recipient SET status='waiting' WHERE recipient_id={$match['recipient_id']}");
            $msg = "Match rejected and records rolled back.";
        } else {
            $err = "Match not found.";
        }

    } elseif ($action === 'add_transplant') {
        $did = (int)$_POST['donor_id'];
        $rid = (int)$_POST['recipient_id'];
        $oid = (int)$_POST['organ_id'];
        $hid = $_POST['hospital_id'] !== '' ? (int)$_POST['hospital_id'] : 'NULL';
        $date = sanitize($conn, $_POST['transplant_date']);
        $st = sanitize($conn, $_POST['status']);
        $notes = sanitize($conn, $_POST['notes']);

        $checkOrgan = $conn->query("
            SELECT *
            FROM organ
            WHERE organ_id=$oid
              AND approval_status='accepted'
              AND availability_status IN ('matched','available')
            LIMIT 1
        ");

        if ($checkOrgan->num_rows === 0) {
            $err = "Only accepted organs can be recorded for transplant.";
        } else {
            $conn->query("
                INSERT INTO transplant
                (donor_id, recipient_id, organ_id, hospital_id, transplant_date, status, notes)
                VALUES
                ($did, $rid, $oid, $hid, '$date', '$st', '$notes')
            ");

            $conn->query("UPDATE organ SET availability_status='used' WHERE organ_id=$oid");
            $conn->query("UPDATE recipient SET status='transplanted' WHERE recipient_id=$rid");
            $msg = "Transplant recorded successfully.";
        }
    }
}

$matches = $conn->query("
    SELECT
        m.*,
        r.full_name AS rec_name,
        r.blood_group AS rec_blood,
        r.needed_organ_type,
        o.organ_type,
        o.approval_status,
        o.hospital_id,
        d.full_name AS donor_name,
        d.blood_group AS donor_blood,
        h.hospital_name
    FROM match_record m
    JOIN recipient r ON m.recipient_id = r.recipient_id
    JOIN organ o ON m.organ_id = o.organ_id
    JOIN donor d ON o.donor_id = d.donor_id
    LEFT JOIN hospital h ON o.hospital_id = h.hospital_id
    ORDER BY m.matched_on DESC
");

$transplants = $conn->query("
    SELECT
        t.*,
        d.full_name AS donor_name,
        r.full_name AS rec_name,
        o.organ_type,
        h.hospital_name
    FROM transplant t
    JOIN donor d ON t.donor_id = d.donor_id
    JOIN recipient r ON t.recipient_id = r.recipient_id
    JOIN organ o ON t.organ_id = o.organ_id
    LEFT JOIN hospital h ON t.hospital_id = h.hospital_id
    ORDER BY t.transplant_date DESC, t.transplant_id DESC
");

$recipients = $conn->query("
    SELECT recipient_id, full_name, blood_group, needed_organ_type
    FROM recipient
    WHERE status='waiting'
");
$r_arr = [];
while ($r = $recipients->fetch_assoc()) $r_arr[] = $r;

$avail_organs = $conn->query("
    SELECT
        o.organ_id,
        o.organ_type,
        o.hospital_id,
        d.full_name AS donor_name,
        d.blood_group,
        h.hospital_name
    FROM organ o
    JOIN donor d ON o.donor_id = d.donor_id
    LEFT JOIN hospital h ON o.hospital_id = h.hospital_id
    WHERE o.availability_status='available'
      AND o.approval_status='accepted'
");
$o_arr = [];
while ($o = $avail_organs->fetch_assoc()) $o_arr[] = $o;

$donors = $conn->query("
    SELECT donor_id, full_name
    FROM donor
    WHERE eligibility_status='eligible'
");
$d_arr = [];
while ($d = $donors->fetch_assoc()) $d_arr[] = $d;

$organs_all = $conn->query("
    SELECT organ_id, organ_type
    FROM organ
    WHERE approval_status='accepted'
");
$oa = [];
while ($o = $organs_all->fetch_assoc()) $oa[] = $o;

$hospitals = $conn->query("
    SELECT hospital_id, hospital_name
    FROM hospital
    WHERE subscription_status='active'
");
$h_arr = [];
while ($h = $hospitals->fetch_assoc()) $h_arr[] = $h;
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Matches & Transplants — Admin</title>
<link rel="stylesheet" href="../css/style.css">
</head>
<body>
<div class="wrapper">
<?php renderSidebar('admin'); ?>

<div class="main-content">
<div class="topbar">
    <h1>🔗 Matches & Transplants</h1>
    <div class="topbar-right">
        <button class="btn btn-primary btn-sm" onclick="document.getElementById('matchModal').style.display='flex'">+ Create Match</button>
        <button class="btn btn-success btn-sm" onclick="document.getElementById('transplantModal').style.display='flex'">+ Record Transplant</button>
    </div>
</div>

<div class="page-body">
    <?php if ($msg): ?>
        <div class="alert alert-success"><?= htmlspecialchars($msg) ?></div>
    <?php endif; ?>
    <?php if ($err): ?>
        <div class="alert alert-danger"><?= htmlspecialchars($err) ?></div>
    <?php endif; ?>

    <div class="card">
        <div class="card-title">🔗 Match Records</div>
        <div class="table-wrap">
            <table>
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Recipient</th>
                        <th>Organ</th>
                        <th>Donor</th>
                        <th>Hospital</th>
                        <th>Approval</th>
                        <th>Blood Match</th>
                        <th>Date</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                <?php if ($matches->num_rows === 0): ?>
                    <tr>
                        <td colspan="10" style="text-align:center;color:#64748b;padding:30px">No match records found.</td>
                    </tr>
                <?php else: ?>
                    <?php while ($m = $matches->fetch_assoc()): ?>
                    <tr>
                        <td><?= $m['match_id'] ?></td>
                        <td>
                            <?= htmlspecialchars($m['rec_name']) ?><br>
                            <small><?= htmlspecialchars($m['needed_organ_type']) ?> · <?= htmlspecialchars($m['rec_blood']) ?></small>
                        </td>
                        <td><?= htmlspecialchars($m['organ_type']) ?></td>
                        <td><?= htmlspecialchars($m['donor_name']) ?><br><small><?= htmlspecialchars($m['donor_blood']) ?></small></td>
                        <td><?= htmlspecialchars($m['hospital_name'] ?? '—') ?></td>
                        <td>
                            <?php
                            $ac = ['pending'=>'badge-warning', 'accepted'=>'badge-success', 'rejected'=>'badge-danger'];
                            ?>
                            <span class="badge <?= $ac[$m['approval_status']] ?? 'badge-secondary' ?>">
                                <?= ucfirst($m['approval_status']) ?>
                            </span>
                        </td>
                        <td>
                            <?php $bm = $m['rec_blood'] === $m['donor_blood']; ?>
                            <span class="badge <?= $bm ? 'badge-success' : 'badge-warning' ?>">
                                <?= $bm ? '✓ Match' : '⚠ Different' ?>
                            </span>
                        </td>
                        <td><?= date('M d, Y', strtotime($m['matched_on'])) ?></td>
                        <td>
                            <?php $sc = ['pending'=>'badge-warning','confirmed'=>'badge-success','rejected'=>'badge-danger']; ?>
                            <span class="badge <?= $sc[$m['match_status']] ?>"><?= ucfirst($m['match_status']) ?></span>
                        </td>
                        <td>
                            <?php if ($m['match_status'] === 'pending'): ?>
                                <form method="POST" style="display:inline">
                                    <input type="hidden" name="action" value="confirm">
                                    <input type="hidden" name="match_id" value="<?= $m['match_id'] ?>">
                                    <button type="submit" class="btn btn-sm btn-success">Confirm</button>
                                </form>
                                <form method="POST" style="display:inline">
                                    <input type="hidden" name="action" value="reject_match">
                                    <input type="hidden" name="match_id" value="<?= $m['match_id'] ?>">
                                    <button type="submit" class="btn btn-sm btn-danger">Reject</button>
                                </form>
                            <?php else: ?>
                                <span style="color:#64748b;font-size:12px">Done</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <div class="card">
        <div class="card-title">✅ Transplant Records</div>
        <div class="table-wrap">
            <table>
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Donor</th>
                        <th>Recipient</th>
                        <th>Organ</th>
                        <th>Hospital</th>
                        <th>Date</th>
                        <th>Status</th>
                        <th>Notes</th>
                    </tr>
                </thead>
                <tbody>
                <?php if ($transplants->num_rows === 0): ?>
                    <tr>
                        <td colspan="8" style="text-align:center;color:#64748b;padding:30px">No transplant records found.</td>
                    </tr>
                <?php else: ?>
                    <?php while ($t = $transplants->fetch_assoc()): ?>
                    <tr>
                        <td><?= $t['transplant_id'] ?></td>
                        <td><?= htmlspecialchars($t['donor_name']) ?></td>
                        <td><?= htmlspecialchars($t['rec_name']) ?></td>
                        <td><?= htmlspecialchars($t['organ_type']) ?></td>
                        <td><?= htmlspecialchars($t['hospital_name'] ?? '—') ?></td>
                        <td><?= htmlspecialchars($t['transplant_date']) ?></td>
                        <td><span class="badge badge-success"><?= htmlspecialchars($t['status']) ?></span></td>
                        <td><small><?= htmlspecialchars($t['notes']) ?></small></td>
                    </tr>
                    <?php endwhile; ?>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
</div>
</div>

<!-- Match Modal -->
<div id="matchModal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.5);z-index:999;align-items:center;justify-content:center">
<div style="background:#fff;border-radius:16px;padding:32px;width:520px;position:relative">
    <button onclick="document.getElementById('matchModal').style.display='none'" style="position:absolute;top:16px;right:16px;background:none;border:none;font-size:20px;cursor:pointer">✕</button>
    <h3 style="margin-bottom:20px">Create Match</h3>

    <form method="POST">
        <input type="hidden" name="action" value="add_match">

        <div class="form-group">
            <label>Recipient (Waiting)</label>
            <select name="recipient_id" class="form-control" required>
                <option value="">Select</option>
                <?php foreach ($r_arr as $r): ?>
                    <option value="<?= $r['recipient_id'] ?>">
                        <?= htmlspecialchars($r['full_name']) ?> — <?= htmlspecialchars($r['blood_group']) ?> needs <?= htmlspecialchars($r['needed_organ_type']) ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="form-group">
            <label>Accepted Available Organ</label>
            <select name="organ_id" class="form-control" required>
                <option value="">Select</option>
                <?php foreach ($o_arr as $o): ?>
                    <option value="<?= $o['organ_id'] ?>">
                        <?= htmlspecialchars($o['organ_type']) ?> from <?= htmlspecialchars($o['donor_name']) ?> (<?= htmlspecialchars($o['blood_group']) ?>)
                        <?= $o['hospital_name'] ? ' — ' . htmlspecialchars($o['hospital_name']) : '' ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>

        <button type="submit" class="btn btn-primary" style="width:100%">Create Match</button>
    </form>
</div>
</div>

<!-- Transplant Modal -->
<div id="transplantModal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.5);z-index:999;align-items:center;justify-content:center">
<div style="background:#fff;border-radius:16px;padding:32px;width:520px;max-height:90vh;overflow-y:auto;position:relative">
    <button onclick="document.getElementById('transplantModal').style.display='none'" style="position:absolute;top:16px;right:16px;background:none;border:none;font-size:20px;cursor:pointer">✕</button>
    <h3 style="margin-bottom:20px">Record Transplant</h3>

    <form method="POST">
        <input type="hidden" name="action" value="add_transplant">

        <div class="form-group">
            <label>Donor</label>
            <select name="donor_id" class="form-control" required>
                <option value="">Select</option>
                <?php foreach ($d_arr as $d): ?>
                    <option value="<?= $d['donor_id'] ?>"><?= htmlspecialchars($d['full_name']) ?></option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="form-group">
            <label>Recipient</label>
            <select name="recipient_id" class="form-control" required>
                <option value="">Select</option>
                <?php foreach ($r_arr as $r): ?>
                    <option value="<?= $r['recipient_id'] ?>"><?= htmlspecialchars($r['full_name']) ?></option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="form-group">
            <label>Accepted Organ</label>
            <select name="organ_id" class="form-control" required>
                <option value="">Select</option>
                <?php foreach ($oa as $o): ?>
                    <option value="<?= $o['organ_id'] ?>"><?= htmlspecialchars($o['organ_type']) ?> (ID <?= $o['organ_id'] ?>)</option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="form-group">
            <label>Hospital</label>
            <select name="hospital_id" class="form-control">
                <option value="">Select</option>
                <?php foreach ($h_arr as $h): ?>
                    <option value="<?= $h['hospital_id'] ?>"><?= htmlspecialchars($h['hospital_name']) ?></option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="form-group">
            <label>Date</label>
            <input type="date" name="transplant_date" class="form-control" value="<?= date('Y-m-d') ?>" required>
        </div>

        <div class="form-group">
            <label>Status</label>
            <input name="status" class="form-control" value="Successful">
        </div>

        <div class="form-group">
            <label>Notes</label>
            <textarea name="notes" class="form-control" rows="2"></textarea>
        </div>

        <button type="submit" class="btn btn-success" style="width:100%">Record Transplant</button>
    </form>
</div>
</div>

</body>
</html>