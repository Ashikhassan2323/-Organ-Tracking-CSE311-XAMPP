<?php
session_start();
require_once '../includes/auth.php';
require_once '../includes/config.php';
require_once '../includes/sidebar.php';
requireAdmin();

$msg = ''; $err = '';

// Handle actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'add') {
        $name = sanitize($conn, $_POST['full_name']);
        $gender = sanitize($conn, $_POST['gender']);
        $dob = sanitize($conn, $_POST['date_of_birth']);
        $bg = sanitize($conn, $_POST['blood_group']);
        $phone = sanitize($conn, $_POST['phone']);
        $addr = sanitize($conn, $_POST['address']);
        $med = sanitize($conn, $_POST['medical_status']);
        $elig = sanitize($conn, $_POST['eligibility_status']);
        $pass = hashPassword($_POST['password'] ?: 'Donor@123');
        $conn->query("INSERT INTO donor (full_name,gender,date_of_birth,blood_group,phone,address,medical_status,eligibility_status,password_hash)
            VALUES ('$name','$gender','$dob','$bg','$phone','$addr','$med','$elig','$pass')");
        $msg = "Donor added successfully.";

    } elseif ($action === 'update_eligibility') {
        $id = (int)$_POST['donor_id'];
        $elig = sanitize($conn, $_POST['eligibility_status']);
        $med = sanitize($conn, $_POST['medical_status']);
        $conn->query("UPDATE donor SET eligibility_status='$elig', medical_status='$med' WHERE donor_id=$id");
        $msg = "Donor status updated.";

    } elseif ($action === 'delete') {
        $id = (int)$_POST['donor_id'];
        if ($conn->query("DELETE FROM donor WHERE donor_id=$id")) $msg = "Donor deleted.";
        else $err = "Cannot delete: donor has linked organs/records.";
    }
}

$donors = $conn->query("SELECT * FROM donor ORDER BY registration_date DESC");
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Donors — Admin</title>
<link rel="stylesheet" href="../css/style.css">
</head>
<body>
<div class="wrapper">
<?php renderSidebar('admin'); ?>
<div class="main-content">
<div class="topbar">
    <h1>💉 Manage Donors</h1>
    <div class="topbar-right">
        <button class="btn btn-primary btn-sm" onclick="document.getElementById('addModal').style.display='flex'">+ Add Donor</button>
    </div>
</div>
<div class="page-body">
<?php if ($msg): ?><div class="alert alert-success"><?= $msg ?></div><?php endif; ?>
<?php if ($err): ?><div class="alert alert-danger"><?= $err ?></div><?php endif; ?>

<div class="card">
<div class="table-wrap">
<table>
<thead>
<tr><th>#</th><th>Name</th><th>Blood</th><th>Phone</th><th>Medical</th><th>Eligibility</th><th>Registered</th><th>Actions</th></tr>
</thead>
<tbody>
<?php while ($d = $donors->fetch_assoc()): ?>
<tr>
    <td><?= $d['donor_id'] ?></td>
    <td><b><?= htmlspecialchars($d['full_name']) ?></b><br><small style="color:#64748b"><?= $d['gender'] ?>, <?= $d['blood_group'] ?></small></td>
    <td><span class="badge badge-info"><?= $d['blood_group'] ?></span></td>
    <td><?= htmlspecialchars($d['phone']) ?></td>
    <td><?= htmlspecialchars($d['medical_status']) ?></td>
    <td>
        <?php $ec=['eligible'=>'badge-success','ineligible'=>'badge-danger','pending'=>'badge-warning']; ?>
        <span class="badge <?= $ec[$d['eligibility_status']] ?>"><?= ucfirst($d['eligibility_status']) ?></span>
    </td>
    <td><?= date('M d, Y', strtotime($d['registration_date'])) ?></td>
    <td>
        <form method="POST" style="display:inline">
            <input type="hidden" name="action" value="update_eligibility">
            <input type="hidden" name="donor_id" value="<?= $d['donor_id'] ?>">
            <select name="eligibility_status" class="form-control" style="display:inline;width:110px;padding:4px 6px;font-size:12px">
                <option value="pending" <?= $d['eligibility_status']==='pending'?'selected':'' ?>>Pending</option>
                <option value="eligible" <?= $d['eligibility_status']==='eligible'?'selected':'' ?>>Eligible</option>
                <option value="ineligible" <?= $d['eligibility_status']==='ineligible'?'selected':'' ?>>Ineligible</option>
            </select>
            <input type="hidden" name="medical_status" value="<?= htmlspecialchars($d['medical_status']) ?>">
            <button type="submit" class="btn btn-sm btn-success">✓</button>
        </form>
        <form method="POST" style="display:inline" onsubmit="return confirm('Delete this donor?')">
            <input type="hidden" name="action" value="delete">
            <input type="hidden" name="donor_id" value="<?= $d['donor_id'] ?>">
            <button type="submit" class="btn btn-sm btn-danger">🗑</button>
        </form>
    </td>
</tr>
<?php endwhile; ?>
</tbody>
</table>
</div>
</div>
</div>
</div>
</div>

<!-- Add Modal -->
<div id="addModal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.5);z-index:999;align-items:center;justify-content:center">
<div style="background:#fff;border-radius:16px;padding:32px;width:560px;max-height:90vh;overflow-y:auto;position:relative">
<button onclick="document.getElementById('addModal').style.display='none'" style="position:absolute;top:16px;right:16px;background:none;border:none;font-size:20px;cursor:pointer">✕</button>
<h3 style="margin-bottom:20px">Add New Donor</h3>
<form method="POST">
<input type="hidden" name="action" value="add">
<div class="form-row">
    <div class="form-group"><label>Full Name</label><input name="full_name" class="form-control" required></div>
    <div class="form-group"><label>Gender</label>
        <select name="gender" class="form-control"><option>Male</option><option>Female</option><option>Other</option></select>
    </div>
</div>
<div class="form-row">
    <div class="form-group"><label>Date of Birth</label><input type="date" name="date_of_birth" class="form-control"></div>
    <div class="form-group"><label>Blood Group</label>
        <select name="blood_group" class="form-control">
            <?php foreach(['A+','A-','B+','B-','O+','O-','AB+','AB-'] as $bg) echo "<option>$bg</option>"; ?>
        </select>
    </div>
</div>
<div class="form-row">
    <div class="form-group"><label>Phone</label><input name="phone" class="form-control" required></div>
    <div class="form-group"><label>Medical Status</label><input name="medical_status" class="form-control" value="Pending Review"></div>
</div>
<div class="form-group"><label>Address</label><textarea name="address" class="form-control" rows="2"></textarea></div>
<div class="form-row">
    <div class="form-group"><label>Eligibility</label>
        <select name="eligibility_status" class="form-control"><option value="pending">Pending</option><option value="eligible">Eligible</option></select>
    </div>
    <div class="form-group"><label>Password (default: Donor@123)</label><input type="password" name="password" class="form-control" placeholder="Leave blank for default"></div>
</div>
<button type="submit" class="btn btn-primary" style="width:100%">Add Donor</button>
</form>
</div>
</div>
</body>
</html>
